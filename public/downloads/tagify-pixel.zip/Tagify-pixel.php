<?php
/**
 * Plugin Name: Tagify Gateway Pixel
 * Plugin URI:  https://tagify.top
 * Description: Connects WooCommerce to Tagify Gateway, sGTM, and all major ad platforms.
 * Version:     3.4.0
 * Author:      Tagify
 * License:     GPL-2.0+
 * Text Domain: tagify-pixel
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Tagify_Ultimate_Pixel {

    const OPTION  = 'tagify_settings';
    const VERSION = '3.4.0';

    private $consent_presets;

    /* ------------------------------------------------------------------ */
    /*  BOOTSTRAP                                                           */
    /* ------------------------------------------------------------------ */

    public function __construct() {
        $this->consent_presets = [
            'gdpr'   => [
                'label'                   => 'GDPR (EU) — Opt-in Required',
                'analytics_storage'       => 'denied',
                'ad_storage'              => 'denied',
                'ad_user_data'            => 'denied',
                'ad_personalization'      => 'denied',
                'functionality_storage'   => 'denied',
                'personalization_storage' => 'denied',
                'security_storage'        => 'granted',
                'wait_for_update'         => 500,
            ],
            'ccpa'   => [
                'label'                   => 'CCPA (California) — Opt-out Model',
                'analytics_storage'       => 'granted',
                'ad_storage'              => 'denied',
                'ad_user_data'            => 'denied',
                'ad_personalization'      => 'denied',
                'functionality_storage'   => 'granted',
                'personalization_storage' => 'denied',
                'security_storage'        => 'granted',
            ],
            'lgpd'   => [
                'label'                   => 'LGPD (Brazil) — Opt-in Required',
                'analytics_storage'       => 'denied',
                'ad_storage'              => 'denied',
                'ad_user_data'            => 'denied',
                'ad_personalization'      => 'denied',
                'functionality_storage'   => 'denied',
                'personalization_storage' => 'denied',
                'security_storage'        => 'granted',
                'wait_for_update'         => 500,
            ],
            'pipeda' => [
                'label'                   => 'PIPEDA (Canada) — Moderate',
                'analytics_storage'       => 'granted',
                'ad_storage'              => 'denied',
                'ad_user_data'            => 'denied',
                'ad_personalization'      => 'denied',
                'functionality_storage'   => 'granted',
                'personalization_storage' => 'denied',
                'security_storage'        => 'granted',
            ],
            'pdpa'   => [
                'label'                   => 'PDPA (Thailand) — Opt-in Required',
                'analytics_storage'       => 'denied',
                'ad_storage'              => 'denied',
                'ad_user_data'            => 'denied',
                'ad_personalization'      => 'denied',
                'functionality_storage'   => 'denied',
                'personalization_storage' => 'denied',
                'security_storage'        => 'granted',
                'wait_for_update'         => 500,
            ],
            'pecr'   => [
                'label'                   => 'PECR / ePrivacy (UK) — Opt-in Required',
                'analytics_storage'       => 'denied',
                'ad_storage'              => 'denied',
                'ad_user_data'            => 'denied',
                'ad_personalization'      => 'denied',
                'functionality_storage'   => 'denied',
                'personalization_storage' => 'denied',
                'security_storage'        => 'granted',
                'wait_for_update'         => 500,
            ],
            'global' => [
                'label'                   => 'Global Default (Most Restrictive)',
                'analytics_storage'       => 'denied',
                'ad_storage'              => 'denied',
                'ad_user_data'            => 'denied',
                'ad_personalization'      => 'denied',
                'functionality_storage'   => 'denied',
                'personalization_storage' => 'denied',
                'security_storage'        => 'granted',
                'wait_for_update'         => 500,
            ],
        ];

        add_action( 'plugins_loaded',              [ $this, 'maybe_migrate' ] );
        add_action( 'admin_menu',                  [ $this, 'add_menu' ] );
        add_action( 'admin_post_tagify_save',      [ $this, 'save_settings' ] );
        add_action( 'admin_post_tagify_reset',     [ $this, 'reset_settings' ] );
        add_action( 'wp_ajax_tagify_test_webhook', [ $this, 'ajax_test_webhook' ] );
        add_action( 'admin_enqueue_scripts',       [ $this, 'admin_assets' ] );

        add_action( 'init',         [ $this, 'cookie_keeper' ] );
        add_action( 'wp_head',      [ $this, 'inject_head' ], 1 );
        add_action( 'wp_body_open', [ $this, 'inject_body' ], 1 );
        add_action( 'wp_footer',    [ $this, 'inject_consent_banner' ], 100 );

        add_action( 'woocommerce_thankyou',                [ $this, 'track_purchase' ],     10, 1 );
        add_action( 'woocommerce_new_order',               [ $this, 'webhook_purchase' ],   10, 1 );
        add_action( 'woocommerce_order_status_processing', [ $this, 'webhook_processing' ], 10, 1 );
        add_action( 'woocommerce_order_status_completed',  [ $this, 'webhook_completed' ],  10, 1 );
        add_action( 'woocommerce_order_refunded',          [ $this, 'webhook_refund' ],     10, 1 );
    }

    /* ------------------------------------------------------------------ */
    /*  HELPERS                                                             */
    /* ------------------------------------------------------------------ */

    private function get( string $key, $default = '' ) {
        $opts = get_option( self::OPTION, [] );
        return $opts[ $key ] ?? $default;
    }

    /* ------------------------------------------------------------------ */
    /*  MIGRATION (v2 → v3)                                                */
    /* ------------------------------------------------------------------ */

    public function maybe_migrate() {
        if ( get_option( self::OPTION ) !== false ) return;

        $old_key    = get_option( 'tagify_cdp_pixel_key', '' );
        $old_domain = get_option( 'tagify_cdp_tracking_domain', '' );

        if ( $old_key || $old_domain ) {
            $domain = $old_domain ? rtrim( $old_domain, '/' ) : '';
            if ( $domain && ! preg_match( '#^https?://#', $domain ) ) {
                $domain = 'https://' . $domain;
            }
            update_option( self::OPTION, [
                'pixel_key'       => $old_key,
                'tracking_domain' => $domain,
            ] );
        }
    }

    /* ------------------------------------------------------------------ */
    /*  ADMIN MENU                                                          */
    /* ------------------------------------------------------------------ */

    public function add_menu() {
        add_menu_page(
            'Tagify Gateway Pixel',
            'Tagify Gateway',
            'manage_options',
            'tagify-pixel',
            [ $this, 'render_settings' ],
            'data:image/svg+xml;base64,' . base64_encode( '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="white"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>' ),
            58
        );
    }

    /* ------------------------------------------------------------------ */
    /*  SAVE SETTINGS                                                       */
    /* ------------------------------------------------------------------ */

    public function save_settings() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
        check_admin_referer( 'tagify_save' );

        $new = [];

        foreach ( [ 'pixel_key', 'tracking_domain', 'web_gtm_id', 'sgtm_url', 'sgtm_identifier',
                    'wh_url', 'consent_position', 'consent_preset', 'consent_text',
                    'consent_accept', 'consent_decline',
                    'consent_primary_color', 'consent_bg_color', 'consent_text_color',
                    'privacy_policy_label', 'cookie_policy_label' ] as $k ) {
            $new[ $k ] = sanitize_text_field( $_POST[ $k ] ?? '' );
        }

        // URL fields — separate sanitization
        foreach ( [ 'privacy_policy_url', 'cookie_policy_url' ] as $k ) {
            $new[ $k ] = esc_url_raw( $_POST[ $k ] ?? '' );
        }

        if ( $new['tracking_domain'] && ! preg_match( '#^https?://#', $new['tracking_domain'] ) ) {
            $new['tracking_domain'] = 'https://' . $new['tracking_domain'];
        }
        $new['tracking_domain'] = rtrim( $new['tracking_domain'], '/' );

        if ( $new['sgtm_url'] && ! preg_match( '#^https?://#', $new['sgtm_url'] ) ) {
            $new['sgtm_url'] = 'https://' . $new['sgtm_url'];
        }
        $new['sgtm_url'] = rtrim( $new['sgtm_url'], '/' );

        // Checkboxes
        foreach ( [
            'user_data_prolonging', 'cookie_keeper',
            'dl_ecommerce', 'dl_user_data', 'dl_user_prolonging', 'dl_decorate',
            'wh_enabled', 'wh_purchase', 'wh_processing', 'wh_completed', 'wh_refund',
            'consent_enabled', 'consent_send_gateway', 'consent_push_dl',
            'stop_before_consent', 'block_cookies_before_consent',
            'page_blocking', 'reload_after_consent', 'reload_on_consent',
        ] as $k ) {
            $new[ $k ] = isset( $_POST[ $k ] ) ? '1' : '0';
        }

        $new['gtm_mode'] = ( ( $_POST['gtm_mode'] ?? 'disabled' ) === 'enabled' ) ? 'enabled' : 'disabled';

        if ( empty( $new['consent_preset'] ) || ! isset( $this->consent_presets[ $new['consent_preset'] ] ) ) {
            $new['consent_preset'] = 'gdpr';
        }

        update_option( self::OPTION, $new );
        wp_redirect( admin_url( 'admin.php?page=tagify-pixel&saved=1' ) );
        exit;
    }

    /* ------------------------------------------------------------------ */
    /*  RESET SETTINGS                                                      */
    /* ------------------------------------------------------------------ */

    public function reset_settings() {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Unauthorized' );
        check_admin_referer( 'tagify_reset' );
        delete_option( self::OPTION );
        wp_redirect( admin_url( 'admin.php?page=tagify-pixel&reset=1' ) );
        exit;
    }

    /* ------------------------------------------------------------------ */
    /*  AJAX: TEST WEBHOOK                                                  */
    /* ------------------------------------------------------------------ */

    public function ajax_test_webhook() {
        check_ajax_referer( 'tagify_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Unauthorized' );

        $url = $this->get( 'wh_url' );
        if ( ! $url ) wp_send_json_error( 'No webhook URL configured.' );

        $response = wp_remote_post( $url, [
            'headers'     => [ 'Content-Type' => 'application/json' ],
            'body'        => wp_json_encode( [ 'event' => 'test', 'timestamp' => time(), 'order_id' => 0, 'source' => 'Tagify Gateway Test' ] ),
            'timeout'     => 10,
            'blocking'    => true,
            'data_format' => 'body',
        ] );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( $response->get_error_message() );
        }
        wp_send_json_success( 'Webhook delivered. HTTP ' . wp_remote_retrieve_response_code( $response ) );
    }

    /* ------------------------------------------------------------------ */
    /*  ADMIN ASSETS                                                        */
    /* ------------------------------------------------------------------ */

    public function admin_assets( $hook ) {
        if ( $hook !== 'toplevel_page_tagify-pixel' ) return;

        // Google Fonts: Sora (display) + Manrope (body) + JetBrains Mono
        wp_enqueue_style(
            'tagify-gfonts',
            'https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=Manrope:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap',
            [],
            null
        );

        $this->admin_css();
        $this->admin_js();
    }

    private function admin_css() { ?>
<style>
/* ── Base ───────────────────────────────────────────────────────────────── */
.tg-wrap *{box-sizing:border-box}
.tg-wrap{
    max-width:920px;
    font-family:'Manrope',system-ui,sans-serif;
    color:#0d0d0d;
}

/* ── Header ─────────────────────────────────────────────────────────────── */
.tg-header{
    background:#0d0d0d !important;
    color:#f5f3ee !important;
    padding:26px 32px;
    border-radius:12px;
    margin-bottom:24px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:16px;
}
.tg-header h1{
    margin:0 !important;
    font-family:'Sora',system-ui,sans-serif !important;
    font-size:22px !important;
    font-weight:700 !important;
    color:#f5f3ee !important;
    letter-spacing:-.3px;
    line-height:1.2;
}
.tg-header p{
    margin:5px 0 0 !important;
    font-size:13px !important;
    color:rgba(245,243,238,.6) !important;
    font-family:'Manrope',sans-serif !important;
}
.tg-header-badge{
    background:rgba(255,90,60,.18);
    border:1px solid rgba(255,90,60,.35);
    color:#ff7a5c;
    padding:4px 12px;
    border-radius:20px;
    font-size:11.5px;
    font-weight:600;
    white-space:nowrap;
    font-family:'JetBrains Mono',monospace;
}

/* ── Tabs ───────────────────────────────────────────────────────────────── */
.tg-tabs{
    display:flex;gap:2px;
    border-bottom:2px solid #e8e4dd;
    margin-bottom:24px;
    flex-wrap:wrap;
}
.tg-tab{
    padding:9px 18px;cursor:pointer;border:none;background:none;
    font-family:'Manrope',sans-serif;font-size:13px;font-weight:500;color:#6b6358;
    border-bottom:2px solid transparent;margin-bottom:-2px;
    border-radius:6px 6px 0 0;transition:all .15s;
}
.tg-tab.active{color:#ff5a3c !important;border-bottom-color:#ff5a3c !important;background:#fff8f6}
.tg-tab:hover:not(.active){color:#0d0d0d;background:#f5f3ee}

/* ── Cards ──────────────────────────────────────────────────────────────── */
.tg-card{
    background:#fff;border:1px solid #e8e4dd;
    border-radius:10px;padding:22px 24px;margin-bottom:16px;
}
.tg-card h3{
    margin:0 0 16px;
    font-family:'Sora',sans-serif;font-size:11px;font-weight:700;
    color:#6b6358;letter-spacing:.1em;text-transform:uppercase;
    padding-bottom:12px;border-bottom:1px solid #f0ece6;
}

/* ── Row grid ───────────────────────────────────────────────────────────── */
.tg-row{
    display:grid;grid-template-columns:220px 1fr;
    align-items:start;gap:12px;padding:11px 0;
    border-bottom:1px solid #f7f5f2;
}
.tg-row:last-child{border-bottom:none}
.tg-row>label{font-size:13px;font-weight:500;color:#0d0d0d;padding-top:8px}
.tg-row input[type=text],
.tg-row input[type=url],
.tg-row textarea,
.tg-row select{
    width:100%;padding:8px 11px;
    border:1.5px solid #ddd8d0;border-radius:7px;
    font-family:'Manrope',sans-serif;font-size:13px;
    outline:none;color:#0d0d0d;background:#fdfcfa;
    transition:border-color .18s,box-shadow .18s;
}
.tg-row code{
    font-family:'JetBrains Mono',monospace;font-size:12px;
    background:#f5f3ee;padding:1px 5px;border-radius:4px;color:#0d0d0d;
}
.tg-row input[type=text]:focus,
.tg-row input[type=url]:focus,
.tg-row textarea:focus,
.tg-row select:focus{
    border-color:#ff5a3c;
    box-shadow:0 0 0 3px rgba(255,90,60,.1);
}
.tg-row small{display:block;color:#9b9488;font-size:11.5px;margin-top:5px;line-height:1.55}

/* ── Toggle switch ──────────────────────────────────────────────────────── */
.tg-switch-wrap{display:flex;align-items:center;gap:10px;cursor:pointer;user-select:none}
.tg-switch{position:relative;display:inline-block;width:42px;height:23px;flex-shrink:0}
.tg-switch input{opacity:0;width:0;height:0;position:absolute}
.tg-slider{
    position:absolute;cursor:pointer;inset:0;
    background:#d4cfc8;border-radius:23px;transition:.2s;
}
.tg-slider:before{
    position:absolute;content:"";height:17px;width:17px;
    left:3px;bottom:3px;background:#fff;border-radius:50%;
    transition:.2s;box-shadow:0 1px 3px rgba(0,0,0,.2);
}
.tg-switch input:checked+.tg-slider{background:#ff5a3c}
.tg-switch input:checked+.tg-slider:before{transform:translateX(19px)}
.tg-switch-label{font-size:13px;color:#0d0d0d}

/* ── Radio options ──────────────────────────────────────────────────────── */
.tg-radio-row{padding:10px 0;border-bottom:1px solid #f7f5f2}
.tg-radio-row:last-of-type{border-bottom:none}
.tg-radio-option{display:flex;gap:10px;align-items:flex-start;cursor:pointer}
.tg-radio-option input[type=radio]{margin-top:3px;accent-color:#ff5a3c;flex-shrink:0}
.tg-radio-option-body strong{display:block;font-size:13px;font-weight:600;color:#0d0d0d}
.tg-radio-option-body span{display:block;font-size:12px;color:#9b9488;margin-top:2px}

/* ── Preset grid ────────────────────────────────────────────────────────── */
.tg-preset-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:6px}
.tg-preset-btn{
    padding:8px 12px;border:1.5px solid #ddd8d0;border-radius:7px;
    cursor:pointer;font-family:'Manrope',sans-serif;font-size:12px;font-weight:500;
    color:#0d0d0d;background:#fdfcfa;text-align:left;transition:all .15s;
}
.tg-preset-btn:hover{border-color:#ff5a3c;color:#ff5a3c}
.tg-preset-btn.active{border-color:#ff5a3c;background:#fff5f3;color:#cc3d22}

/* ── Buttons ────────────────────────────────────────────────────────────── */
.tg-btn{
    background:#ff5a3c;color:#fff;border:none;
    padding:10px 26px;border-radius:7px;
    font-family:'Manrope',sans-serif;font-size:14px;font-weight:600;
    cursor:pointer;transition:background .15s;
}
.tg-btn:hover{background:#e04a2e}
.tg-btn-outline{
    background:#fdfcfa;color:#ff5a3c;border:1.5px solid #ff5a3c;
    padding:8px 16px;border-radius:7px;
    font-family:'Manrope',sans-serif;font-size:13px;font-weight:500;
    cursor:pointer;transition:all .15s;
}
.tg-btn-outline:hover{background:#fff5f3}
.tg-btn-reset{
    background:#fdfcfa;color:#b91c1c;border:1.5px solid #fca5a5;
    padding:10px 22px;border-radius:7px;
    font-family:'Manrope',sans-serif;font-size:13px;font-weight:600;
    cursor:pointer;margin-left:10px;transition:all .15s;
}
.tg-btn-reset:hover{background:#fef2f2;border-color:#b91c1c}

/* ── Notices ────────────────────────────────────────────────────────────── */
.tg-notice{
    padding:11px 16px;border-radius:8px;
    margin-bottom:18px;font-size:13px;font-weight:500;
    font-family:'Manrope',sans-serif;
}
.tg-notice.success{background:#f0fdf4;border:1px solid #86efac;color:#166534}
.tg-notice.info{background:#fff8f6;border:1px solid #ffb8a8;color:#9a2d15}

/* ── Webhook result ─────────────────────────────────────────────────────── */
#tg-webhook-result{
    margin-top:8px;font-size:13px;
    font-family:'JetBrains Mono',monospace;
}

/* ── Footer ─────────────────────────────────────────────────────────────── */
.tg-footer-actions{display:flex;align-items:center;padding-top:8px}
.tg-divider{width:1px;height:20px;background:#ddd8d0;margin:0 12px}
/* ── Color pickers ──────────────────────────────────────────────────────── */
.tg-color-row{display:flex;flex-direction:column;gap:4px}
.tg-color-row label{font-size:11px;font-weight:500;color:#6b6358}
.tg-color-row input[type=color]{width:44px;height:34px;padding:2px 3px;border:1.5px solid #ddd8d0;border-radius:7px;cursor:pointer;background:#fdfcfa}

</style>
    <?php }

    private function admin_js() { ?>
<script>
document.addEventListener('DOMContentLoaded', function(){

    // ── Tab switching ──────────────────────────────────────────────────────
    var tabs  = document.querySelectorAll('.tg-tab');
    var panes = document.querySelectorAll('.tg-pane');
    var activeTab = localStorage.getItem('tg_active_tab') || 'gateway';

    function showTab(id) {
        tabs.forEach(function(t){ t.classList.toggle('active', t.dataset.tab === id); });
        panes.forEach(function(p){ p.style.display = (p.id === 'tg-pane-' + id) ? '' : 'none'; });
        localStorage.setItem('tg_active_tab', id);
    }
    tabs.forEach(function(t){ t.addEventListener('click', function(){ showTab(t.dataset.tab); }); });
    showTab(activeTab);

    // ── GTM radio ─────────────────────────────────────────────────────────
    var gtmRadios = document.querySelectorAll('input[name="gtm_mode"]');
    var gtmFields = document.getElementById('gtm-enabled-fields');
    function updateGtm(){
        var val = document.querySelector('input[name="gtm_mode"]:checked');
        if (gtmFields) gtmFields.style.display = (val && val.value === 'enabled') ? '' : 'none';
    }
    gtmRadios.forEach(function(r){ r.addEventListener('change', updateGtm); });
    updateGtm();

    // ── Consent toggle ─────────────────────────────────────────────────────
    var consentChk    = document.getElementById('consent_enabled');
    var consentFields = document.getElementById('consent-fields');
    function updateConsent(){
        if (consentFields) consentFields.style.display = (consentChk && consentChk.checked) ? '' : 'none';
    }
    if (consentChk){ consentChk.addEventListener('change', updateConsent); updateConsent(); }

    // ── Consent preset buttons ─────────────────────────────────────────────
    var presetInput = document.getElementById('consent_preset_input');
    var presetBtns  = document.querySelectorAll('.tg-preset-btn');
    presetBtns.forEach(function(btn){
        btn.addEventListener('click', function(){
            presetBtns.forEach(function(b){ b.classList.remove('active'); });
            btn.classList.add('active');
            if (presetInput) presetInput.value = btn.dataset.preset;
        });
    });

    // ── Test webhook ───────────────────────────────────────────────────────
    var testBtn = document.getElementById('tg-test-wh');
    if (testBtn){
        testBtn.addEventListener('click', function(){
            var result = document.getElementById('tg-webhook-result');
            result.textContent = 'Sending…';
            var fd = new FormData();
            fd.append('action', 'tagify_test_webhook');
            fd.append('nonce', tagifyAdmin.nonce);
            fetch(tagifyAdmin.ajax, { method:'POST', body:fd })
                .then(function(r){ return r.json(); })
                .then(function(d){ result.textContent = d.success ? '✓ ' + d.data : '✗ ' + d.data; })
                .catch(function(){ result.textContent = '✗ Network error'; });
        });
    }

    // ── Reset confirmation ─────────────────────────────────────────────────
    var resetBtn = document.getElementById('tg-reset-btn');
    if (resetBtn){
        resetBtn.addEventListener('click', function(e){
            if (!confirm('This will erase ALL Tagify Gateway settings. Continue?')) e.preventDefault();
        });
    }
});
</script>
<script>var tagifyAdmin=<?= wp_json_encode([
    'ajax'  => admin_url( 'admin-ajax.php' ),
    'nonce' => wp_create_nonce( 'tagify_nonce' ),
]) ?>;</script>
    <?php }

    /* ------------------------------------------------------------------ */
    /*  ADMIN PAGE RENDER                                                   */
    /* ------------------------------------------------------------------ */

    public function render_settings() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $s          = get_option( self::OPTION, [] );
        $g          = fn( $k, $d = '' ) => esc_attr( $s[ $k ] ?? $d );
        $c          = fn( $k ) => ( ( $s[ $k ] ?? '0' ) === '1' ) ? 'checked' : '';
        $gtm        = $s['gtm_mode'] ?? 'disabled';
        $cur_preset = $s['consent_preset'] ?? 'gdpr';
        ?>
<div class="tg-wrap">

<div class="tg-header">
    <div>
        <h1>Tagify Gateway Pixel</h1>
        <p>Unified tracking for WooCommerce — Gateway · sGTM · Consent Mode V2</p>
    </div>
    <span class="tg-header-badge">v<?= self::VERSION ?></span>
</div>

<?php if ( isset( $_GET['saved'] ) ) : ?>
<div class="tg-notice success">✓ Settings saved.</div>
<?php endif; ?>
<?php if ( isset( $_GET['reset'] ) ) : ?>
<div class="tg-notice info">↺ All settings reset to defaults.</div>
<?php endif; ?>

<div class="tg-tabs">
    <button class="tg-tab" data-tab="gateway">Gateway Config</button>
    <button class="tg-tab" data-tab="sgtm">sGTM / GTM</button>
    <button class="tg-tab" data-tab="datalayer">Data Layer</button>
    <button class="tg-tab" data-tab="webhooks">Webhooks</button>
    <button class="tg-tab" data-tab="consent">Consent Mode V2</button>
</div>

<form method="post" action="<?= admin_url( 'admin-post.php' ) ?>">
<?php wp_nonce_field( 'tagify_save' ); ?>
<input type="hidden" name="action" value="tagify_save">

<!-- ══════════════════════ TAB: GATEWAY ══════════════════════ -->
<div class="tg-pane" id="tg-pane-gateway">
<div class="tg-card">
    <h3>Gateway Configuration</h3>
    <div class="tg-row">
        <label>Pixel Key</label>
        <div>
            <input type="text" name="pixel_key" value="<?= $g( 'pixel_key' ) ?>" placeholder="tg_live_xxxxxxxxxxxxxxxx">
            <small>Found in your Tagify Gateway dashboard under your workspace.</small>
        </div>
    </div>
    <div class="tg-row">
        <label>Tracking Domain</label>
        <div>
            <input type="text" name="tracking_domain" value="<?= $g( 'tracking_domain' ) ?>" placeholder="https://track.yourdomain.com">
            <small>Your custom proxy domain (https://). Leave blank to use site URL.</small>
        </div>
    </div>
    <div class="tg-row">
        <label>Store Customer Data</label>
        <div>
            <label class="tg-switch-wrap">
                <label class="tg-switch">
                    <input type="checkbox" name="user_data_prolonging" <?= $c( 'user_data_prolonging' ) ?>>
                    <span class="tg-slider"></span>
                </label>
                <span class="tg-switch-label">After purchase, save hashed billing data for enriching future Gateway events</span>
            </label>
            <small>Only affects Tagify Gateway. Does not influence the Data Layer — configure that separately in the Data Layer tab.</small>
        </div>
    </div>
</div>
</div>

<!-- ══════════════════════ TAB: SGTM ══════════════════════ -->
<div class="tg-pane" id="tg-pane-sgtm">
<div class="tg-card">
    <h3>Google Tag Manager</h3>
    <div class="tg-row">
        <label>GTM Script Mode</label>
        <div>
            <div class="tg-radio-row">
                <label class="tg-radio-option">
                    <input type="radio" name="gtm_mode" value="enabled" <?= $gtm === 'enabled' ? 'checked' : '' ?>>
                    <div class="tg-radio-option-body">
                        <strong>Add GTM script to every page</strong>
                        <span>Embeds the web GTM snippet on all pages of your website.</span>
                    </div>
                </label>
            </div>
            <div class="tg-radio-row">
                <label class="tg-radio-option">
                    <input type="radio" name="gtm_mode" value="disabled" <?= $gtm !== 'enabled' ? 'checked' : '' ?>>
                    <div class="tg-radio-option-body">
                        <strong>Disabled</strong>
                        <span>Use when another plugin already handles GTM.</span>
                    </div>
                </label>
            </div>
        </div>
    </div>
    <div id="gtm-enabled-fields">
        <div class="tg-row">
            <label>Web GTM ID</label>
            <div>
                <input type="text" name="web_gtm_id" value="<?= $g( 'web_gtm_id' ) ?>" placeholder="GTM-XXXXXX">
                <small>Must be formatted as "GTM-XXXXXX".</small>
            </div>
        </div>
        <div class="tg-row">
            <label>Server GTM URL</label>
            <div>
                <input type="text" name="sgtm_url" value="<?= $g( 'sgtm_url' ) ?>" placeholder="https://gtm.yourdomain.com">
                <small>Your sGTM container URL. Leave blank to load from Google's servers.</small>
            </div>
        </div>
        <div class="tg-row">
            <label>Container Identifier</label>
            <div>
                <input type="text" name="sgtm_identifier" value="<?= $g( 'sgtm_identifier' ) ?>" placeholder="5e92acd36f">
                <small>Stape container identifier for the <strong>Custom Loader</strong> power-up (stape.io only).</small>
            </div>
        </div>
        <div class="tg-row">
            <label>Cookie Keeper</label>
            <div>
                <label class="tg-switch-wrap">
                    <label class="tg-switch">
                        <input type="checkbox" name="cookie_keeper" <?= $c( 'cookie_keeper' ) ?>>
                        <span class="tg-slider"></span>
                    </label>
                    <span class="tg-switch-label">Extend tracking cookies server-side (Safari ITP fix)</span>
                </label>
                <small>Mirrors the stape.io Cookie Keeper power-up via WordPress on every page load.</small>
            </div>
        </div>
    </div>
</div>
</div>

<!-- ══════════════════════ TAB: DATA LAYER ══════════════════════ -->
<div class="tg-pane" id="tg-pane-datalayer">
<div class="tg-card">
    <h3>GA4 / GTM Data Layer</h3>
    <div class="tg-row">
        <label>Push Ecommerce Events</label>
        <div>
            <label class="tg-switch-wrap">
                <label class="tg-switch">
                    <input type="checkbox" name="dl_ecommerce" <?= $c( 'dl_ecommerce' ) ?>>
                    <span class="tg-slider"></span>
                </label>
                <span class="tg-switch-label">Push <code>page_view</code> + ecommerce events to <code>window.dataLayer</code> in GA4 format</span>
            </label>
        </div>
    </div>
    <div class="tg-row">
        <label>Include User Data</label>
        <div>
            <label class="tg-switch-wrap">
                <label class="tg-switch">
                    <input type="checkbox" name="dl_user_data" <?= $c( 'dl_user_data' ) ?>>
                    <span class="tg-slider"></span>
                </label>
                <span class="tg-switch-label">Append <code>user_data</code> (click IDs, client ID) to each dataLayer push</span>
            </label>
            <small>Includes click-ID signals (fbclid, gclid, ttclid, etc.). Independent of the Gateway "Store Customer Data" setting.</small>
        </div>
    </div>
    <div class="tg-row">
        <label>Store Customer Data</label>
        <div>
            <label class="tg-switch-wrap">
                <label class="tg-switch">
                    <input type="checkbox" name="dl_user_prolonging" <?= $c( 'dl_user_prolonging' ) ?>>
                    <span class="tg-slider"></span>
                </label>
                <span class="tg-switch-label">Also include hashed billing data (em, ph, fn, ln…) in <code>user_data</code> on subsequent page loads</span>
            </label>
            <small>Only active when "Include User Data" is also on. Separate from Gateway's customer data storage.</small>
        </div>
    </div>
    <div class="tg-row">
        <label>Decorate Event Names</label>
        <div>
            <label class="tg-switch-wrap">
                <label class="tg-switch">
                    <input type="checkbox" name="dl_decorate" <?= $c( 'dl_decorate' ) ?>>
                    <span class="tg-slider"></span>
                </label>
                <span class="tg-switch-label">Append <code>_tagify</code> suffix (e.g. <code>purchase_tagify</code>)</span>
            </label>
        </div>
    </div>
</div>
</div>

<!-- ══════════════════════ TAB: WEBHOOKS ══════════════════════ -->
<div class="tg-pane" id="tg-pane-webhooks">
<div class="tg-card">
    <h3>Webhook Settings</h3>
    <div class="tg-row">
        <label>Enable Webhooks</label>
        <div>
            <label class="tg-switch-wrap">
                <label class="tg-switch">
                    <input type="checkbox" name="wh_enabled" <?= $c( 'wh_enabled' ) ?>>
                    <span class="tg-slider"></span>
                </label>
                <span class="tg-switch-label">Send order events to an external endpoint</span>
            </label>
        </div>
    </div>
    <div class="tg-row">
        <label>Webhook URL</label>
        <div>
            <input type="url" name="wh_url" value="<?= $g( 'wh_url' ) ?>" placeholder="https://yourapp.com/webhook">
            <small>All enabled events POST JSON to this URL.</small>
        </div>
    </div>
    <div class="tg-row">
        <label>Events to Fire</label>
        <div style="display:flex;flex-direction:column;gap:10px">
            <label class="tg-switch-wrap">
                <label class="tg-switch"><input type="checkbox" name="wh_purchase" <?= $c( 'wh_purchase' ) ?>><span class="tg-slider"></span></label>
                <span class="tg-switch-label">New Order</span>
            </label>
            <label class="tg-switch-wrap">
                <label class="tg-switch"><input type="checkbox" name="wh_processing" <?= $c( 'wh_processing' ) ?>><span class="tg-slider"></span></label>
                <span class="tg-switch-label">Order Processing</span>
            </label>
            <label class="tg-switch-wrap">
                <label class="tg-switch"><input type="checkbox" name="wh_completed" <?= $c( 'wh_completed' ) ?>><span class="tg-slider"></span></label>
                <span class="tg-switch-label">Order Completed</span>
            </label>
            <label class="tg-switch-wrap">
                <label class="tg-switch"><input type="checkbox" name="wh_refund" <?= $c( 'wh_refund' ) ?>><span class="tg-slider"></span></label>
                <span class="tg-switch-label">Order Refunded</span>
            </label>
        </div>
    </div>
    <div class="tg-row">
        <label>Test Webhook</label>
        <div>
            <button type="button" id="tg-test-wh" class="tg-btn-outline">Send Test Payload</button>
            <div id="tg-webhook-result"></div>
        </div>
    </div>
</div>
</div>

<!-- ══════════════════════ TAB: CONSENT ══════════════════════ -->
<div class="tg-pane" id="tg-pane-consent">
<div class="tg-card">
    <h3>Consent Mode V2 / GDPR</h3>
    <div class="tg-row">
        <label>Enable Consent Mode</label>
        <div>
            <label class="tg-switch-wrap">
                <label class="tg-switch">
                    <input type="checkbox" name="consent_enabled" id="consent_enabled" <?= $c( 'consent_enabled' ) ?>>
                    <span class="tg-slider"></span>
                </label>
                <span class="tg-switch-label">Inject Google Consent Mode V2 defaults and show cookie banner</span>
            </label>
        </div>
    </div>
    <div id="consent-fields">
        <div class="tg-row">
            <label>Compliance Preset</label>
            <div>
                <input type="hidden" name="consent_preset" id="consent_preset_input" value="<?= esc_attr( $cur_preset ) ?>">
                <div class="tg-preset-grid">
                    <?php foreach ( $this->consent_presets as $key => $preset ) : ?>
                    <button type="button" class="tg-preset-btn <?= $key === $cur_preset ? 'active' : '' ?>" data-preset="<?= esc_attr( $key ) ?>">
                        <?= esc_html( $preset['label'] ) ?>
                    </button>
                    <?php endforeach; ?>
                </div>
                <small style="margin-top:8px">
                    Controls Google Consent Mode V2 defaults before user interaction.<br>
                    <strong>GDPR/LGPD/PECR/PDPA</strong>: all denied (opt-in). &nbsp;
                    <strong>CCPA/PIPEDA</strong>: analytics granted, ads denied (opt-out).
                </small>
            </div>
        </div>
        <div class="tg-row">
            <label>Banner Position</label>
            <select name="consent_position">
                <?php foreach ( [
                    'bottom'       => 'Bottom Bar',
                    'top'          => 'Top Bar',
                    'bottom-left'  => 'Bottom Left',
                    'bottom-right' => 'Bottom Right',
                    'center'       => 'Center Modal',
                ] as $v => $l ) : ?>
                <option value="<?= $v ?>" <?= selected( $s['consent_position'] ?? 'bottom', $v, false ) ?>><?= $l ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="tg-row">
            <label>Page Blocking</label>
            <div>
                <label class="tg-switch-wrap">
                    <label class="tg-switch">
                        <input type="checkbox" name="page_blocking" <?= $c( 'page_blocking' ) ?>>
                        <span class="tg-slider"></span>
                    </label>
                    <span class="tg-switch-label">Show full-screen overlay behind banner — blocks all page interaction until a decision is made</span>
                </label>
                <small>Works with any banner position. Recommended for strict GDPR / PECR compliance.</small>
            </div>
        </div>
        <div class="tg-row">
            <label>Banner Text</label>
            <textarea name="consent_text" rows="2"><?= esc_textarea( $s['consent_text'] ?? 'We use cookies to improve your experience and serve personalised ads.' ) ?></textarea>
        </div>
        <div class="tg-row">
            <label>Accept Button</label>
            <input type="text" name="consent_accept" value="<?= $g( 'consent_accept', 'Accept All' ) ?>">
        </div>
        <div class="tg-row">
            <label>Decline Button</label>
            <input type="text" name="consent_decline" value="<?= $g( 'consent_decline', 'Decline' ) ?>">
        </div>
        <div class="tg-row">
            <label>Banner Colours</label>
            <div>
                <div style="display:flex;gap:20px;flex-wrap:wrap">
                    <div class="tg-color-row">
                        <label>Accent / Buttons</label>
                        <input type="color" name="consent_primary_color" value="<?= esc_attr( $s['consent_primary_color'] ?? '#ff5a3c' ) ?>">
                    </div>
                    <div class="tg-color-row">
                        <label>Background</label>
                        <input type="color" name="consent_bg_color" value="<?= esc_attr( $s['consent_bg_color'] ?? '#f5f3ee' ) ?>">
                    </div>
                    <div class="tg-color-row">
                        <label>Text &amp; Borders</label>
                        <input type="color" name="consent_text_color" value="<?= esc_attr( $s['consent_text_color'] ?? '#0d0d0d' ) ?>">
                    </div>
                </div>
                <small style="margin-top:8px">Applies to banner, floating button, and preferences panel.</small>
            </div>
        </div>
        <div class="tg-row">
            <label>Privacy Policy</label>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
                <div>
                    <input type="url" name="privacy_policy_url" value="<?= esc_attr( $s['privacy_policy_url'] ?? '' ) ?>" placeholder="https://example.com/privacy-policy">
                    <small>URL — leave blank to hide link</small>
                </div>
                <div>
                    <input type="text" name="privacy_policy_label" value="<?= $g( 'privacy_policy_label', 'Privacy Policy' ) ?>" placeholder="Privacy Policy">
                    <small>Link label</small>
                </div>
            </div>
        </div>
        <div class="tg-row">
            <label>Cookie Policy</label>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
                <div>
                    <input type="url" name="cookie_policy_url" value="<?= esc_attr( $s['cookie_policy_url'] ?? '' ) ?>" placeholder="https://example.com/cookie-policy">
                    <small>URL — leave blank to hide link</small>
                </div>
                <div>
                    <input type="text" name="cookie_policy_label" value="<?= $g( 'cookie_policy_label', 'Cookie Policy' ) ?>" placeholder="Cookie Policy">
                    <small>Link label</small>
                </div>
            </div>
        </div>
        <div class="tg-row">
            <label>consent_granted Event</label>
            <div style="display:flex;flex-direction:column;gap:10px">
                <label class="tg-switch-wrap">
                    <label class="tg-switch">
                        <input type="checkbox" name="consent_send_gateway" <?= $c( 'consent_send_gateway' ) ?>>
                        <span class="tg-slider"></span>
                    </label>
                    <span class="tg-switch-label">Send <code>consent_granted</code> event to Tagify Gateway</span>
                </label>
                <label class="tg-switch-wrap">
                    <label class="tg-switch">
                        <input type="checkbox" name="consent_push_dl" <?= $c( 'consent_push_dl' ) ?>>
                        <span class="tg-slider"></span>
                    </label>
                    <span class="tg-switch-label">Push <code>consent_granted</code> event to dataLayer</span>
                </label>
            </div>
        </div>
        <div class="tg-row">
            <label>Compliance Controls</label>
            <div style="display:flex;flex-direction:column;gap:10px">
                <label class="tg-switch-wrap">
                    <label class="tg-switch">
                        <input type="checkbox" name="stop_before_consent" <?= $c( 'stop_before_consent' ) ?>>
                        <span class="tg-slider"></span>
                    </label>
                    <span class="tg-switch-label"><strong>Stop Gateway events before consent</strong> — No tracking fires until the user accepts or declines. Required for strict GDPR / PECR compliance.</span>
                </label>
                <label class="tg-switch-wrap">
                    <label class="tg-switch">
                        <input type="checkbox" name="block_cookies_before_consent" <?= $c( 'block_cookies_before_consent' ) ?>>
                        <span class="tg-slider"></span>
                    </label>
                    <span class="tg-switch-label"><strong>Block tracking cookies before consent</strong> — Advertising cookies (fbp, ttp, gclid…) and the analytics client ID are not written until the relevant consent category is granted.</span>
                </label>
                <label class="tg-switch-wrap">
                    <label class="tg-switch">
                        <input type="checkbox" name="reload_after_consent" <?= $c( 'reload_after_consent' ) ?>>
                        <span class="tg-slider"></span>
                    </label>
                    <span class="tg-switch-label"><strong>Reload page after saving preferences</strong> — Recommended when "Stop Gateway events" is on, so tracking fires correctly on the first page after consent.</span>
                </label>
                <label class="tg-switch-wrap">
                    <label class="tg-switch">
                        <input type="checkbox" name="reload_on_consent" <?= $c( 'reload_on_consent' ) ?>>
                        <span class="tg-slider"></span>
                    </label>
                    <span class="tg-switch-label"><strong>Reload page on consent given</strong> — Reload when the visitor clicks Accept All or Decline All on the initial banner. Useful to fire page events immediately after first-time consent.</span>
                </label>
            </div>
        </div>
    </div>
</div>
</div>

<!-- ══════════════════════ Footer ══════════════════════ -->
<div class="tg-footer-actions">
    <button type="submit" class="tg-btn">Save Settings</button>
    <div class="tg-divider"></div>
    <a id="tg-reset-btn"
       href="<?= wp_nonce_url( admin_url( 'admin-post.php?action=tagify_reset' ), 'tagify_reset' ) ?>"
       class="tg-btn-reset">Reset All Settings</a>
</div>
</form>
</div>
        <?php
    }

    /* ------------------------------------------------------------------ */
    /*  COOKIE KEEPER                                                       */
    /* ------------------------------------------------------------------ */

    public function cookie_keeper() {
        if ( $this->get( 'cookie_keeper' ) !== '1' ) return;
        $expires = time() + ( 365 * 24 * 3600 );
        foreach ( [ '_tg_client_id', '_tg_fbp', '_tg_ttp', '_tg_scid' ] as $name ) {
            if ( isset( $_COOKIE[ $name ] ) ) {
                setcookie( $name, $_COOKIE[ $name ], [
                    'expires'  => $expires,
                    'path'     => '/',
                    'secure'   => is_ssl(),
                    'httponly' => false,
                    'samesite' => 'Lax',
                ] );
            }
        }
    }

    /* ------------------------------------------------------------------ */
    /*  HEAD INJECTION                                                      */
    /* ------------------------------------------------------------------ */

    public function inject_head() {
        $pixel_key       = $this->get( 'pixel_key' );
        $tracking_domain = $this->get( 'tracking_domain' );
        $consent_enabled = $this->get( 'consent_enabled' ) === '1';
        $consent_preset  = $this->get( 'consent_preset', 'gdpr' );

        // Pre-compute preset JSON so the fetch interceptor can include consent
        // signals in every Gateway event even before the footer banner script runs.
        $cs_keys = ['analytics_storage','ad_storage','ad_user_data','ad_personalization',
                    'functionality_storage','personalization_storage','security_storage'];
        $js_preset = [];
        if ( $consent_enabled ) {
            $pr = $this->consent_presets[ $consent_preset ] ?? $this->consent_presets['gdpr'];
            foreach ( $cs_keys as $k ) {
                $js_preset[ $k ] = $pr[ $k ] ?? 'denied';
            }
            $js_preset['security_storage'] = 'granted'; // always grant security
        }
        $js_consent_preset_json = $js_preset ? wp_json_encode( $js_preset ) : '{}';
        $js_consent_enabled     = $consent_enabled ? 'true' : 'false';
        $js_stop_before         = $this->get( 'stop_before_consent' )          === '1' ? 'true' : 'false';
        $js_block_cookies       = $this->get( 'block_cookies_before_consent' ) === '1' ? 'true' : 'false';

        $gtm_mode   = $this->get( 'gtm_mode', 'disabled' );
        $web_gtm_id = $this->get( 'web_gtm_id' );
        $sgtm_url   = rtrim( $this->get( 'sgtm_url' ), '/' );
        $sgtm_id    = $this->get( 'sgtm_identifier' );

        $dl_ecommerce    = $this->get( 'dl_ecommerce' )    === '1' ? 'true' : 'false';
        $dl_user_data    = $this->get( 'dl_user_data' )    === '1' ? 'true' : 'false';
        $dl_user_prolong = $this->get( 'dl_user_prolonging' ) === '1' ? 'true' : 'false';
        $dl_decorate     = $this->get( 'dl_decorate' )     === '1' ? 'true' : 'false';
        // Gateway-side prolonging — only for CDP, passed into JS so JS can decide
        $gw_user_prolong = $this->get( 'user_data_prolonging' ) === '1' ? 'true' : 'false';

        // ── 1. Consent Mode V2 — MUST be first and synchronous ────────────────
        if ( $consent_enabled ) {
            $preset_cfg      = $this->consent_presets[ $consent_preset ] ?? $this->consent_presets['gdpr'];
            $already_granted = isset( $_COOKIE['tagify_consent'] ) && $_COOKIE['tagify_consent'] === 'granted';
            $consent_params  = [
                'analytics_storage', 'ad_storage', 'ad_user_data', 'ad_personalization',
                'functionality_storage', 'personalization_storage', 'security_storage',
            ];
            ?>
<!-- Tagify Gateway: Google Consent Mode V2 -->
<script>
window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}
<?php if ( $already_granted ) : ?>
gtag('consent','default',{analytics_storage:'granted',ad_storage:'granted',ad_user_data:'granted',ad_personalization:'granted',functionality_storage:'granted',personalization_storage:'granted',security_storage:'granted'});
<?php else :
    $obj_parts = [];
    foreach ( $consent_params as $p ) {
        $v           = $preset_cfg[ $p ] ?? 'denied';
        $obj_parts[] = $p . ":'" . esc_js( $v ) . "'";
    }
    if ( ! empty( $preset_cfg['wait_for_update'] ) ) {
        $obj_parts[] = 'wait_for_update:' . (int) $preset_cfg['wait_for_update'];
    }
    echo 'gtag(\'consent\',\'default\',{' . implode( ',', $obj_parts ) . '});' . "\n";
endif; ?>
// JS consent restore — runs synchronously BEFORE GTM loads.
// On cached pages PHP cannot detect the cookie, so this inline
// script reads it client-side and immediately fires a consent
// update so GTM always starts with the correct consent state.
// Handles both new JSON format and legacy 'granted'/'denied' string.
(function(){
    function _tgRC(n){var m=document.cookie.match(new RegExp('(?:^|;\\s*)'+n+'=([^;]*)'));return m?decodeURIComponent(m[1]):null;}
    var _c=_tgRC('tagify_consent');
    if(_c){
        var _s=null;
        try{var _p=JSON.parse(_c);if(_p&&typeof _p==='object')_s=_p;}catch(e){}
        if(!_s){_s={};var _v=_c==='granted'?'granted':'denied';
            ['analytics_storage','ad_storage','ad_user_data','ad_personalization',
             'functionality_storage','personalization_storage'].forEach(function(k){_s[k]=_v;});}
        gtag('consent','update',_s);
    }
})();
</script>
<?php
        }

        // ── 2. GTM snippet ────────────────────────────────────────────────────
        if ( $gtm_mode === 'enabled' && $web_gtm_id ) {
            if ( $sgtm_url && $sgtm_id ) {
                $short_id = preg_replace( '/^GTM-/i', '', $web_gtm_id );
                $loader   = esc_js( $sgtm_url . '/' . $sgtm_id . '.min.js?stq=' );
                ?>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'<?= $loader ?>'+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','<?= esc_js( $short_id ) ?>');</script>
<!-- End Google Tag Manager -->
<?php
            } elseif ( $sgtm_url ) {
                $loader = esc_js( $sgtm_url . '/gtm.js?id=' );
                ?>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'<?= $loader ?>'+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','<?= esc_js( $web_gtm_id ) ?>');</script>
<!-- End Google Tag Manager -->
<?php
            } else { ?>
<!-- Google Tag Manager -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','<?= esc_js( $web_gtm_id ) ?>');</script>
<!-- End Google Tag Manager -->
<?php
            }
        }

        // ── 3. TagifyConfig + flags ───────────────────────────────────────────
        if ( $pixel_key ) {
            $base     = $tracking_domain ?: rtrim( home_url(), '/' );
            $endpoint = $base . '/v1/e';
            ?>
<!-- Tagify Gateway: Config -->
<script>
window.dataLayer=window.dataLayer||[];
window.TagifyConfig={
    pixelKey:'<?= esc_js( $pixel_key ) ?>',
    endpoint:'<?= esc_js( $endpoint ) ?>',
    consentEnabled:<?= $js_consent_enabled ?>,
    consentPreset:<?= $js_consent_preset_json ?>,
    stopBeforeConsent:<?= $js_stop_before ?>,
    blockCookies:<?= $js_block_cookies ?>,
    // Read existing consent cookie RIGHT NOW so canSetAdCookie() / canSetAnalyticsCookie()
    // work correctly when the tracking IIFE runs below — the footer banner JS is too late.
    currentConsent:(function(){
        try{
            var _m=document.cookie.match(/(?:^|;\s*)tagify_consent=([^;]*)/);
            if(!_m) return null;
            var _v=decodeURIComponent(_m[1]);
            var _p=JSON.parse(_v);
            if(_p&&typeof _p==='object') return _p;
            // Legacy 'granted'/'denied' string
            var _s={};
            ['analytics_storage','ad_storage','ad_user_data','ad_personalization',
             'functionality_storage','personalization_storage','security_storage']
            .forEach(function(k){_s[k]=(_v==='granted')?'granted':'denied';});
            _s.security_storage='granted';
            return _s;
        }catch(e){ return null; }
    })()
};
window._tgDL={
    ecommerce:<?= $dl_ecommerce ?>,
    userData:<?= $dl_user_data ?>,
    userProlong:<?= $dl_user_prolong ?>,
    decorate:<?= $dl_decorate ?>
};
window._tgGW={
    userProlong:<?= $gw_user_prolong ?>
};
// Intercept Tagify fetch calls — injects page_title, page_referrer,
// and (when consent mode is on) the full consent signals at event root.
(function(){
    var _ep=window.TagifyConfig.endpoint;
    var _of=window.fetch;
    if(typeof _of!=='function') return;
    window.fetch=function(url,options){
        if(typeof url==='string' && url.indexOf(_ep)!==-1 && options && options.body){
            try{
                var body=JSON.parse(options.body);
                var inject=function(evt){
                    if(!evt || typeof evt!=='object' || Array.isArray(evt)) return;
                    // Page context — at event root alongside event_source_url
                    evt.page_title    = document.title;
                    evt.page_referrer = document.referrer||'';
                    // Consent signals — reflects the user's current consent state
                    if(window.TagifyConfig.consentEnabled){
                        var cs=window.TagifyConfig.currentConsent||window.TagifyConfig.consentPreset;
                        if(cs) evt.consent={
                            analytics_storage:     cs.analytics_storage||'denied',
                            ad_storage:            cs.ad_storage||'denied',
                            ad_user_data:          cs.ad_user_data||'denied',
                            ad_personalization:    cs.ad_personalization||'denied',
                            functionality_storage: cs.functionality_storage||'denied',
                            personalization_storage:cs.personalization_storage||'denied'
                        };
                    }
                };
                Array.isArray(body) ? body.forEach(inject) : inject(body);
                options=Object.assign({},options,{body:JSON.stringify(body)});
            }catch(e){}
        }
        return _of.apply(this,arguments);
    };
})();
</script>
<?php
        }

        // ── 4. tagify.js ──────────────────────────────────────────────────────
        if ( $pixel_key && $tracking_domain ) : ?>
<script src="<?= esc_url( $tracking_domain . '/tagify.js' ) ?>" async></script>
<?php elseif ( $pixel_key ) : ?>
<script src="<?= esc_url( home_url( '/tagify.js' ) ) ?>" async></script>
<?php endif;

        if ( ! $pixel_key ) return;

        // ── 5. Page context ───────────────────────────────────────────────────
        $is_product  = is_product();
        $is_category = is_product_category() || is_product_tag() || is_shop();
        $is_cart     = is_cart();
        $is_checkout = is_checkout() && ! is_wc_endpoint_url( 'order-received' );
        $is_search   = is_search();
        $search_term = $is_search ? get_search_query() : '';

        $cdp_event        = 'page_view';
        $ga4_event        = 'page_view';
        $cdp_payload_json = 'null';
        $ga4_payload_json = 'null';

        if ( $is_product ) {
            global $product;
            if ( ! $product instanceof WC_Product ) {
                $product = wc_get_product( get_the_ID() );
            }
            if ( $product instanceof WC_Product ) {
                $pid      = (string) ( $product->get_sku() ?: $product->get_id() );
                $price    = (float) $product->get_price();
                $currency = get_woocommerce_currency();
                $name     = $product->get_name();

                $cdp_event        = 'view_item';
                $cdp_payload_json = wp_json_encode( [
                    'value'    => $price,
                    'currency' => $currency,
                    'items'    => [ [ 'item_id' => $pid, 'item_name' => $name, 'price' => $price, 'quantity' => 1 ] ],
                ] );
                $ga4_event        = 'view_item';
                $ga4_payload_json = wp_json_encode( [
                    'currency' => $currency,
                    'value'    => $price,
                    'items'    => [ [ 'item_id' => $pid, 'item_name' => $name, 'price' => $price, 'quantity' => 1, 'currency' => $currency ] ],
                ] );
            }

        } elseif ( $is_cart ) {
            $cdp_event = 'view_cart';
            $ga4_event = 'view_cart';
            if ( function_exists( 'WC' ) && isset( WC()->cart ) && ! WC()->cart->is_empty() ) {
                $items = []; $ga4items = [];
                foreach ( WC()->cart->get_cart() as $ci ) {
                    $cp       = $ci['data'];
                    $pid      = (string) ( $cp->get_sku() ?: $cp->get_id() );
                    $qty      = (int) $ci['quantity'];
                    $price    = (float) $cp->get_price();
                    $items[]    = [ 'item_id' => $pid, 'item_name' => $cp->get_name(), 'price' => $price, 'quantity' => $qty ];
                    $ga4items[] = [ 'item_id' => $pid, 'item_name' => $cp->get_name(), 'price' => $price, 'quantity' => $qty, 'currency' => get_woocommerce_currency() ];
                }
                $total            = (float) WC()->cart->get_total( 'edit' );
                $currency         = get_woocommerce_currency();
                $cdp_payload_json = wp_json_encode( [ 'value' => $total, 'currency' => $currency, 'items' => $items ] );
                $ga4_payload_json = wp_json_encode( [ 'currency' => $currency, 'value' => $total, 'items' => $ga4items ] );
            }

        } elseif ( $is_checkout ) {
            $cdp_event = 'begin_checkout';
            $ga4_event = 'begin_checkout';
            if ( function_exists( 'WC' ) && isset( WC()->cart ) && ! WC()->cart->is_empty() ) {
                $items = []; $ga4items = [];
                foreach ( WC()->cart->get_cart() as $ci ) {
                    $cp       = $ci['data'];
                    $pid      = (string) ( $cp->get_sku() ?: $cp->get_id() );
                    $qty      = (int) $ci['quantity'];
                    $price    = (float) $cp->get_price();
                    $items[]    = [ 'item_id' => $pid, 'item_name' => $cp->get_name(), 'price' => $price, 'quantity' => $qty ];
                    $ga4items[] = [ 'item_id' => $pid, 'item_name' => $cp->get_name(), 'price' => $price, 'quantity' => $qty, 'currency' => get_woocommerce_currency() ];
                }
                $total            = (float) WC()->cart->get_total( 'edit' );
                $currency         = get_woocommerce_currency();
                $cdp_payload_json = wp_json_encode( [ 'value' => $total, 'currency' => $currency, 'items' => $items ] );
                $ga4_payload_json = wp_json_encode( [ 'currency' => $currency, 'value' => $total, 'items' => $ga4items ] );
            }

        } elseif ( $is_category ) {
            $cdp_event = 'view_item_list';
            $ga4_event = 'view_item_list';
        } elseif ( $is_search ) {
            $cdp_event = 'search';
            $ga4_event = 'search';
        }
        ?>
<!-- Tagify Gateway: Front-end Tracking -->
<script>
(function(){
    // ── Hybrid storage (cookie primary, localStorage backup) ───────────────
    function tgSet(k,v){
        try{localStorage.setItem(k,v);}catch(e){}
        var d=new Date();d.setTime(d.getTime()+(90*24*60*60*1000));
        document.cookie=k+'='+encodeURIComponent(v)+';expires='+d.toUTCString()+';path=/;SameSite=Lax';
    }
    function tgGet(k){
        var n=k+'=',ca=document.cookie.split(';');
        for(var i=0;i<ca.length;i++){var c=ca[i].trim();if(c.indexOf(n)===0)return decodeURIComponent(c.substring(n.length));}
        try{return localStorage.getItem(k);}catch(e){return null;}
    }

    // ── Helpers to check per-category consent before writing cookies ─────────
    function canSetAdCookie(){
        if(!window.TagifyConfig.blockCookies) return true;
        var cs=window.TagifyConfig.currentConsent;
        return cs ? cs.ad_storage==='granted' : false;
    }
    function canSetAnalyticsCookie(){
        if(!window.TagifyConfig.blockCookies) return true;
        var cs=window.TagifyConfig.currentConsent;
        return cs ? cs.analytics_storage==='granted' : false;
    }

    // ── Capture URL click-IDs synchronously (before page load) ────────────
    var params=new URLSearchParams(window.location.search);
    if(canSetAdCookie()){
        if(params.has('ttclid'))                       tgSet('_tg_ttclid',params.get('ttclid'));
        if(params.has('ScCid')||params.has('sccid'))   tgSet('_tg_sccid',params.get('ScCid')||params.get('sccid'));
        if(params.has('gclid'))                        tgSet('_tg_gclid',params.get('gclid'));
        if(params.has('fbclid'))                       tgSet('_tg_fbc','fb.1.'+Date.now()+'.'+params.get('fbclid'));
    }

    // Generate persistent identifiers — gated by consent when blockCookies is on
    if(canSetAdCookie()){
        if(!tgGet('_tg_fbp')) tgSet('_tg_fbp','fb.1.'+Date.now()+'.'+Math.round(Math.random()*2147483647));
        if(!tgGet('_tg_ttp')) tgSet('_tg_ttp',Math.random().toString(36).substr(2,15)+Math.random().toString(36).substr(2,15));
    }
    if(canSetAnalyticsCookie()){
        if(!tgGet('_tg_client_id')){
            var uuid='xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,function(c){
                var r=Math.random()*16|0,v=c=='x'?r:(r&0x3|0x8);return v.toString(16);
            });
            tgSet('_tg_client_id',uuid);
        }
    }

    // ── Reinitialise cookies + fire queued events after consent is given ─────
    // Called by the consent banner JS via window.tgReinitAfterConsent(state).
    window.tgReinitAfterConsent=function(cs){
        // (Re-)capture URL params that may still be present in the address bar
        var p=new URLSearchParams(window.location.search);
        if(cs.ad_storage==='granted'){
            if(p.has('ttclid'))                    tgSet('_tg_ttclid',p.get('ttclid'));
            if(p.has('ScCid')||p.has('sccid'))     tgSet('_tg_sccid',p.get('ScCid')||p.get('sccid'));
            if(p.has('gclid'))                     tgSet('_tg_gclid',p.get('gclid'));
            if(p.has('fbclid'))                    tgSet('_tg_fbc','fb.1.'+Date.now()+'.'+p.get('fbclid'));
            if(!tgGet('_tg_fbp')) tgSet('_tg_fbp','fb.1.'+Date.now()+'.'+Math.round(Math.random()*2147483647));
            if(!tgGet('_tg_ttp')) tgSet('_tg_ttp',Math.random().toString(36).substr(2,15)+Math.random().toString(36).substr(2,15));
        }
        if(cs.analytics_storage==='granted'){
            if(!tgGet('_tg_client_id')){
                var uid='xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g,function(c){
                    var r=Math.random()*16|0,v=c=='x'?r:(r&0x3|0x8);return v.toString(16);
                });
                tgSet('_tg_client_id',uid);
            }
        }
        // Fire page events that were blocked before consent
        if(window.TagifyConfig.stopBeforeConsent){
            var gw=buildGatewayUser();
            whenTagifyReady(function(){
                cdpTrack('page_view',null,gw);
                if(cdpEvent==='search'){
                    cdpTrack('search',{custom_data:{search_term:searchTerm}},gw);
                } else if(cdpEvent!=='page_view'){
                    cdpTrack(cdpEvent,cdpPayload,gw);
                }
            });
        }
    };

    // ─────────────────────────────────────────────────────────────────────
    // buildGatewayUser — includes stored billing data if GW prolonging is ON
    // Used exclusively for Tagify Gateway (CDP) calls.
    // ─────────────────────────────────────────────────────────────────────
    function buildGatewayUser(){
        var u={};
        if(window._tgGW && window._tgGW.userProlong){
            try{var s=localStorage.getItem('_tg_user_data');if(s)u=JSON.parse(s);}catch(e){}
        }
        if(tgGet('_tg_ttclid')) u.ttclid=tgGet('_tg_ttclid');
        if(tgGet('_tg_ttp'))    u.ttp=tgGet('_tg_ttp');
        if(tgGet('_tg_fbc'))    u.fbc=tgGet('_tg_fbc');
        if(tgGet('_tg_fbp'))    u.fbp=tgGet('_tg_fbp');
        if(tgGet('_tg_sccid'))  u.sccid=tgGet('_tg_sccid');
        if(tgGet('_tg_gclid'))  u.gclid=tgGet('_tg_gclid');
        u.client_id=tgGet('_tg_client_id');
        return u;
    }

    // ─────────────────────────────────────────────────────────────────────
    // buildDLUser — includes stored billing data ONLY if DL prolonging is ON
    // Used exclusively for dataLayer pushes. Never touched by GW setting.
    // ─────────────────────────────────────────────────────────────────────
    function buildDLUser(){
        var u={};
        if(window._tgDL && window._tgDL.userProlong){
            try{var s=localStorage.getItem('_tg_dl_user_data');if(s)u=JSON.parse(s);}catch(e){}
        }
        if(tgGet('_tg_ttclid')) u.ttclid=tgGet('_tg_ttclid');
        if(tgGet('_tg_ttp'))    u.ttp=tgGet('_tg_ttp');
        if(tgGet('_tg_fbc'))    u.fbc=tgGet('_tg_fbc');
        if(tgGet('_tg_fbp'))    u.fbp=tgGet('_tg_fbp');
        if(tgGet('_tg_sccid'))  u.sccid=tgGet('_tg_sccid');
        if(tgGet('_tg_gclid'))  u.gclid=tgGet('_tg_gclid');
        u.client_id=tgGet('_tg_client_id');
        return u;
    }

    // ─────────────────────────────────────────────────────────────────────
    // dlPush — GA4 schema, exactly ONE push, no separate {ecommerce:null}
    // FIX: removed the separate ecommerce:null clearing push.
    // FIX: always fires even when ga4Ecom is null (e.g. page_view).
    // ─────────────────────────────────────────────────────────────────────
    function dlPush(ga4EventName, ga4Ecom, dlUser){
        if(!window._tgDL || !window._tgDL.ecommerce) return;
        var eventName=window._tgDL.decorate ? ga4EventName+'_tagify' : ga4EventName;
        var payload={event:eventName};
        if(ga4Ecom) payload.ecommerce=ga4Ecom;
        if(window._tgDL.userData && dlUser && Object.keys(dlUser).length) payload.user_data=dlUser;
        window.dataLayer=window.dataLayer||[];
        window.dataLayer.push(payload);
    }

    // ─────────────────────────────────────────────────────────────────────
    // cdpTrack — Tagify Gateway event. event_source_url is set by the SDK.
    // FIX: removed manual event_source_url; SDK handles it in the event obj.
    // ─────────────────────────────────────────────────────────────────────
    var _gwInitDone=false;
    function cdpTrack(eventName, cdpPayload, gwUser){
        if(typeof window.Tagify==='undefined') return;
        if(!_gwInitDone && typeof Tagify.init==='function'){
            Tagify.init(window.TagifyConfig.pixelKey,{endpoint:window.TagifyConfig.endpoint});
            _gwInitDone=true;
        }
        var props=cdpPayload ? JSON.parse(JSON.stringify(cdpPayload)) : {};
        props.pixel_key=window.TagifyConfig ? window.TagifyConfig.pixelKey : '';
        Tagify.track(eventName, props, gwUser||{});
    }

    // Retry until tagify.js async script is ready (up to 4 s)
    function whenTagifyReady(fn,retries){
        retries=retries||0;
        if(typeof window.Tagify!=='undefined'){fn();}
        else if(retries<80){setTimeout(function(){whenTagifyReady(fn,retries+1);},50);}
    }

    // ── PHP-rendered page context ──────────────────────────────────────────
    var cdpEvent   = '<?= esc_js( $cdp_event ) ?>';
    var ga4Event   = '<?= esc_js( $ga4_event ) ?>';
    var cdpPayload = <?= $cdp_payload_json ?>;
    var ga4Payload = <?= $ga4_payload_json ?>;
    var currency   = '<?= esc_js( get_woocommerce_currency() ) ?>';
    var searchTerm = '<?= esc_js( $search_term ) ?>';

    window.addEventListener('load',function(){
        var gwUser = buildGatewayUser();
        var dlUser = buildDLUser();

        // ── Gateway (CDP): fire page_view + specific event ─────────────────────
        // If stopBeforeConsent is on and no consent given yet, skip entirely.
        // tgReinitAfterConsent() will fire the queued events once consent is set.
        if(!window.TagifyConfig.stopBeforeConsent || window.TagifyConfig.currentConsent){
            whenTagifyReady(function(){
                cdpTrack('page_view', null, gwUser);
                if(cdpEvent==='search'){
                    cdpTrack('search',{custom_data:{search_term:searchTerm}},gwUser);
                } else if(cdpEvent!=='page_view'){
                    cdpTrack(cdpEvent, cdpPayload, gwUser);
                }
            });
        }

        // ── DataLayer: ALWAYS push page_view first ────────────────────────────
        if(window._tgDL && window._tgDL.ecommerce){
            var pvName=window._tgDL.decorate ? 'page_view_tagify' : 'page_view';
            var pvObj={event:pvName};
            if(window._tgDL.userData && dlUser && Object.keys(dlUser).length) pvObj.user_data=dlUser;
            window.dataLayer=window.dataLayer||[];
            window.dataLayer.push(pvObj);
        }

        if(ga4Event!=='page_view'){
            dlPush(ga4Event, ga4Payload, dlUser);       // ecommerce event on top
        }

        // ── Add to Cart ────────────────────────────────────────────────────────
        // Uses jQuery added_to_cart hook (fires after WC confirms the add).
        // On product pages: cdpPayload has accurate price/name from PHP.
        // On listing pages: falls back to DOM price extraction.
        if(typeof jQuery!=='undefined'){
            jQuery(document.body).on('added_to_cart',function(e,fragments,hash,$btn){
                var pid='', name='', price=0, qty=1;

                if($btn){
                    pid=String($btn.data('product_sku')||$btn.data('product_id')||'');
                    qty=parseInt($btn.data('quantity'))||1;
                }
                if(jQuery('input.qty').length) qty=parseInt(jQuery('input.qty').val())||qty;

                // Product page: use the PHP-built payload (most accurate)
                if(cdpPayload&&cdpPayload.items&&cdpPayload.items.length){
                    var item=cdpPayload.items[0];
                    price=item.price||0;
                    name=item.item_name||'';
                    pid=pid||item.item_id||'';
                } else if($btn){
                    // Listing page: extract from surrounding DOM
                    var $wrap=$btn.closest('li.product,article.product,.product,.summary');
                    if($wrap.length){
                        var $priceEl=$wrap.find('.woocommerce-Price-amount bdi,.price .amount').first();
                        if($priceEl.length){
                            price=parseFloat($priceEl.text().replace(/[^0-9.,]/g,'').replace(',','.'))||0;
                        }
                        var $nameEl=$wrap.find('.woocommerce-loop-product__title,.product_title').first();
                        if($nameEl.length) name=$nameEl.text().trim();
                    }
                }

                var atcPayload={
                    value:price*qty, currency:currency,
                    items:[{item_id:pid,item_name:name,price:price,quantity:qty}]
                };
                whenTagifyReady(function(){cdpTrack('add_to_cart',atcPayload,gwUser);});
                dlPush('add_to_cart',atcPayload,dlUser);
            });

            // Remove from cart
            // Primary: WooCommerce jQuery event (classic cart + some block cart setups)
            jQuery(document.body).on('removed_from_cart',function(e,fragments,hash,$btn){
                var pid='', name='', price=0, qty=1;
                if($btn){
                    pid  = String($btn.data('product_sku')||$btn.data('product_id')||'');
                    qty  = parseInt($btn.data('quantity'))||1;
                    // Try to grab price from the cart row
                    var $row=$btn.closest('tr.woocommerce-cart-form__cart-item,.cart_item');
                    if($row.length){
                        var $p=$row.find('.woocommerce-Price-amount bdi,.price .amount').first();
                        if($p.length) price=parseFloat($p.text().replace(/[^0-9.,]/g,'').replace(',','.'))||0;
                        var $n=$row.find('.woocommerce-cart-item__name a,td.product-name a').first();
                        if($n.length) name=$n.text().trim();
                    }
                }
                var rmPayload={
                    currency:currency,
                    value:price*qty,
                    items:[{item_id:pid,item_name:name,price:price,quantity:qty}]
                };
                whenTagifyReady(function(){cdpTrack('remove_from_cart',rmPayload,gwUser);});
                dlPush('remove_from_cart',rmPayload,dlUser);
            });

            // Fallback: catch remove-button clicks directly (covers block cart & themes
            // that do not trigger removed_from_cart, or do so without $button param)
            jQuery(document.body).on('click','.remove_from_cart_button,.wc-block-cart-item__remove-link,[data-product_id].remove',function(){
                var $btn=jQuery(this);
                var pid=String($btn.data('product_sku')||$btn.data('product_id')||$btn.attr('data-product_id')||'');
                var $row=$btn.closest('tr.woocommerce-cart-form__cart-item,.cart_item,.wc-block-cart-item');
                var price=0, name='', qty=1;
                if($row.length){
                    var $p=$row.find('.woocommerce-Price-amount bdi,.price .amount,.wc-block-cart-item__prices .wc-block-formatted-money-amount').first();
                    if($p.length) price=parseFloat($p.text().replace(/[^0-9.,]/g,'').replace(',','.'))||0;
                    var $n=$row.find('.woocommerce-cart-item__name a,.wc-block-cart-item__product-name').first();
                    if($n.length) name=$n.text().trim();
                    var $q=$row.find('input.qty,.wc-block-cart-item__quantity input');
                    if($q.length) qty=parseInt($q.val())||1;
                }
                var rmPayload={
                    currency:currency,
                    value:price*qty,
                    items:[{item_id:pid,item_name:name,price:price,quantity:qty}]
                };
                whenTagifyReady(function(){cdpTrack('remove_from_cart',rmPayload,gwUser);});
                dlPush('remove_from_cart',rmPayload,dlUser);
            });

            // Payment info
            jQuery('form.checkout').on('checkout_place_order',function(){
                whenTagifyReady(function(){cdpTrack('add_payment_info',cdpPayload,gwUser);});
                if(ga4Payload) dlPush('add_payment_info',ga4Payload,dlUser);
            });
        }

        // ── Form / Lead capture ────────────────────────────────────────────────
        document.addEventListener('wpcf7mailsent',            function(){whenTagifyReady(function(){cdpTrack('generate_lead',null,gwUser);});});
        document.addEventListener('wpformsAjaxSubmitSuccess', function(){whenTagifyReady(function(){cdpTrack('generate_lead',null,gwUser);});});
        if(window.jQuery){
            jQuery(document).on('gform_confirmation_loaded',  function(){whenTagifyReady(function(){cdpTrack('generate_lead',null,gwUser);});});
        }
    });
})();
</script>
<?php
    }

    /* ------------------------------------------------------------------ */
    /*  BODY INJECTION — GTM noscript                                       */
    /* ------------------------------------------------------------------ */

    public function inject_body() {
        $gtm_mode   = $this->get( 'gtm_mode', 'disabled' );
        $web_gtm_id = $this->get( 'web_gtm_id' );
        $sgtm_url   = rtrim( $this->get( 'sgtm_url' ), '/' );
        $sgtm_id    = $this->get( 'sgtm_identifier' );

        if ( $gtm_mode !== 'enabled' || ! $web_gtm_id ) return;

        if ( $sgtm_url && $sgtm_id ) {
            $short_id = preg_replace( '/^GTM-/i', '', $web_gtm_id );
            $ns_url   = $sgtm_url . '/ns.html?id=' . rawurlencode( $short_id );
        } elseif ( $sgtm_url ) {
            $ns_url = $sgtm_url . '/ns.html?id=' . rawurlencode( $web_gtm_id );
        } else {
            $ns_url = 'https://www.googletagmanager.com/ns.html?id=' . rawurlencode( $web_gtm_id );
        }
        ?>
<!-- Google Tag Manager (noscript) -->
<noscript><iframe src="<?= esc_url( $ns_url ) ?>" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager (noscript) -->
<?php
    }

    /* ------------------------------------------------------------------ */
    /*  CONSENT BANNER                                                      */
    /* ------------------------------------------------------------------ */

    public function inject_consent_banner() {
        if ( $this->get( 'consent_enabled' ) !== '1' ) return;

        $text         = $this->get( 'consent_text',    'We use cookies to improve your experience and serve personalised ads.' );
        $accept       = $this->get( 'consent_accept',  'Accept All' );
        $decline      = $this->get( 'consent_decline', 'Decline' );
        $pos          = $this->get( 'consent_position', 'bottom' );
        $send_gateway = $this->get( 'consent_send_gateway' ) === '1' ? 'true' : 'false';
        $push_dl      = $this->get( 'consent_push_dl' )      === '1' ? 'true' : 'false';
        $is_modal     = $pos === 'center';
        $page_block   = $this->get( 'page_blocking' ) === '1';
        $reload_js    = $this->get( 'reload_after_consent' ) === '1' ? 'true' : 'false';
        $reload_consent_js = $this->get( 'reload_on_consent' ) === '1' ? 'true' : 'false';

        // Appearance
        $c_pri  = $this->get( 'consent_primary_color', '#ff5a3c' );
        $c_bg   = $this->get( 'consent_bg_color',      '#f5f3ee' );
        $c_txt  = $this->get( 'consent_text_color',    '#0d0d0d' );
        $c_mute = $this->get( 'consent_text_color',    '#0d0d0d' ) . '99'; // 60% opacity approx

        // Policy links
        $pp_url   = $this->get( 'privacy_policy_url',   '' );
        $pp_label = $this->get( 'privacy_policy_label', 'Privacy Policy' );
        $cp_url   = $this->get( 'cookie_policy_url',    '' );
        $cp_label = $this->get( 'cookie_policy_label',  'Cookie Policy' );

        // Build policy links HTML
        $policy_links = '';
        $links = [];
        if ( $pp_url ) $links[] = '<a href="' . esc_url( $pp_url ) . '" target="_blank" rel="noopener" style="color:' . esc_attr( $c_pri ) . ';text-decoration:none;font-weight:600">' . esc_html( $pp_label ) . '</a>';
        if ( $cp_url ) $links[] = '<a href="' . esc_url( $cp_url ) . '" target="_blank" rel="noopener" style="color:' . esc_attr( $c_pri ) . ';text-decoration:none;font-weight:600">' . esc_html( $cp_label ) . '</a>';
        if ( $links ) {
            $policy_links = '<p style="margin:8px 0 0;font-size:11.5px;opacity:.7">' . implode( ' &nbsp;·&nbsp; ', $links ) . '</p>';
        }

        // Position map — NO automatic overlay on modal (page_blocking is the control)
        $pos_map = [
            'top'          => 'top:0;left:0;right:0;border-top:none;border-bottom:2px solid ' . esc_attr($c_txt) . ';padding:16px 24px;flex-wrap:wrap;gap:14px;',
            'bottom-left'  => 'bottom:20px;left:20px;max-width:400px;border-radius:12px;border:1.5px solid ' . esc_attr($c_txt) . ';box-shadow:0 8px 32px rgba(0,0,0,.15);padding:18px 20px;flex-wrap:wrap;gap:14px;',
            'bottom-right' => 'bottom:20px;right:20px;max-width:400px;border-radius:12px;border:1.5px solid ' . esc_attr($c_txt) . ';box-shadow:0 8px 32px rgba(0,0,0,.15);padding:18px 20px;flex-wrap:wrap;gap:14px;',
            'bottom'       => 'bottom:0;left:0;right:0;border-top:2px solid ' . esc_attr($c_txt) . ';box-shadow:0 -4px 20px rgba(0,0,0,.08);padding:16px 24px;flex-wrap:wrap;gap:14px;',
            'center'       => 'top:50%;left:50%;transform:translate(-50%,-50%);width:calc(100% - 48px);max-width:480px;border-radius:16px;border:1.5px solid ' . esc_attr($c_txt) . ';box-shadow:0 24px 64px rgba(0,0,0,.2);padding:28px 28px 24px;flex-direction:column;gap:18px;',
        ];
        $banner_css = $pos_map[ $pos ] ?? $pos_map['bottom'];
        ?>
<!-- Tagify Gateway: Consent System -->
<style>
#tg-manage-btn:hover{transform:translateY(-2px);box-shadow:0 6px 20px rgba(0,0,0,.2)!important}
#tg-prefs-panel a{color:<?= esc_attr($c_pri) ?>}
</style>

<?php if ( $page_block ) : ?>
<div id="tg-consent-overlay" style="position:fixed;inset:0;background:rgba(0,0,0,.5);backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px);z-index:999997;display:none"></div>
<?php endif; ?>

<!-- Banner -->
<div id="tg-consent-banner" style="position:fixed;<?= $banner_css ?>background:<?= esc_attr($c_bg) ?>;color:<?= esc_attr($c_txt) ?>;z-index:999999;display:none;align-items:<?= $is_modal ? 'flex-start' : 'center' ?>;font-family:'Manrope',system-ui,sans-serif;font-size:14px;line-height:1.5">
<?php if ( $is_modal ) : ?>
    <div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
            <svg width="20" height="20" viewBox="0 0 24 24" style="flex-shrink:0"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z" fill="<?= esc_attr($c_pri) ?>"/></svg>
            <strong style="font-family:'Sora',sans-serif;font-size:15px;color:<?= esc_attr($c_txt) ?>">Privacy &amp; Cookies</strong>
        </div>
        <p style="margin:0;color:<?= esc_attr($c_txt) ?>;font-size:13.5px;line-height:1.65;opacity:.85"><?= esc_html( $text ) ?></p>
        <?= $policy_links ?>
    </div>
    <div style="display:flex;gap:8px;width:100%">
        <button onclick="tgOpenPrefs()" style="flex:1;background:transparent;color:<?= esc_attr($c_txt) ?>;border:1.5px solid <?= esc_attr($c_txt) ?>33;padding:10px 10px;border-radius:8px;cursor:pointer;font-family:'Manrope',sans-serif;font-size:12px;font-weight:500">Manage</button>
        <button onclick="tgDeclineAll()" style="flex:1;background:transparent;color:<?= esc_attr($c_txt) ?>;border:1.5px solid <?= esc_attr($c_txt) ?>33;padding:10px 10px;border-radius:8px;cursor:pointer;font-family:'Manrope',sans-serif;font-size:13px;font-weight:500"><?= esc_html( $decline ) ?></button>
        <button onclick="tgAcceptAll()" style="flex:2;background:<?= esc_attr($c_pri) ?>;color:#fff;border:none;padding:10px 14px;border-radius:8px;cursor:pointer;font-family:'Manrope',sans-serif;font-size:13.5px;font-weight:600"><?= esc_html( $accept ) ?></button>
    </div>
<?php else : ?>
    <div style="flex:1;min-width:200px">
        <p style="margin:0;color:<?= esc_attr($c_txt) ?>;font-size:13.5px"><?= esc_html( $text ) ?></p>
        <?= $policy_links ?>
    </div>
    <div style="display:flex;gap:8px;align-items:center;flex-shrink:0">
        <button onclick="tgOpenPrefs()" style="background:transparent;color:<?= esc_attr($c_txt) ?>;border:none;padding:6px 8px;cursor:pointer;font-family:'Manrope',sans-serif;font-size:12px;font-weight:500;opacity:.6;text-decoration:underline">Manage</button>
        <button onclick="tgDeclineAll()" style="background:transparent;color:<?= esc_attr($c_txt) ?>;border:1.5px solid <?= esc_attr($c_txt) ?>;padding:8px 18px;border-radius:6px;cursor:pointer;font-family:'Manrope',sans-serif;font-size:13px;font-weight:500"><?= esc_html( $decline ) ?></button>
        <button onclick="tgAcceptAll()" style="background:<?= esc_attr($c_pri) ?>;color:#fff;border:none;padding:8px 20px;border-radius:6px;cursor:pointer;font-family:'Manrope',sans-serif;font-size:13px;font-weight:600"><?= esc_html( $accept ) ?></button>
    </div>
<?php endif; ?>
</div>

<!-- Manage Cookies pill button — shown after user has made their choice -->
<button id="tg-manage-btn" onclick="tgOpenPrefs()" style="position:fixed;bottom:24px;left:24px;z-index:999990;display:none;align-items:center;gap:8px;background:<?= esc_attr($c_bg) ?>;color:<?= esc_attr($c_txt) ?>;border:1.5px solid <?= esc_attr($c_txt) ?>;padding:9px 18px 9px 14px;border-radius:24px;cursor:pointer;font-family:'Manrope',system-ui,sans-serif;font-size:13px;font-weight:600;box-shadow:0 3px 14px rgba(0,0,0,.12);transition:transform .15s,box-shadow .15s">
    <span style="font-size:17px;line-height:1">🍪</span> Manage Cookies
</button>

<!-- Preferences panel backdrop -->
<div id="tg-prefs-bd" onclick="tgClosePrefs()" style="position:fixed;inset:0;background:rgba(0,0,0,.45);z-index:999991;display:none"></div>

<!-- Preferences panel — compact centered modal -->
<div id="tg-prefs-panel" style="position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);width:calc(100% - 32px);max-width:500px;max-height:82vh;overflow-y:auto;background:<?= esc_attr($c_bg) ?>;border:1.5px solid <?= esc_attr($c_txt) ?>22;border-radius:16px;z-index:999992;display:none;font-family:'Manrope',system-ui,sans-serif;box-shadow:0 20px 60px rgba(0,0,0,.2)">
    <div style="padding:22px 22px 24px">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:14px">
            <div>
                <h3 style="margin:0 0 3px;font-family:'Sora',sans-serif;font-size:15px;font-weight:700;color:<?= esc_attr($c_txt) ?>">Cookie Preferences</h3>
                <p style="margin:0;font-size:12px;color:<?= esc_attr($c_txt) ?>;opacity:.5">Required cookies are always active.</p>
                <?php if ( $pp_url || $cp_url ) : ?>
                <p style="margin:5px 0 0;font-size:12px">
                    <?php if ( $pp_url ) : ?><a href="<?= esc_url($pp_url) ?>" target="_blank" rel="noopener" style="color:<?= esc_attr($c_pri) ?>;text-decoration:none;font-weight:600"><?= esc_html($pp_label) ?></a><?php endif; ?>
                    <?php if ( $pp_url && $cp_url ) : ?> &nbsp;·&nbsp; <?php endif; ?>
                    <?php if ( $cp_url ) : ?><a href="<?= esc_url($cp_url) ?>" target="_blank" rel="noopener" style="color:<?= esc_attr($c_pri) ?>;text-decoration:none;font-weight:600"><?= esc_html($cp_label) ?></a><?php endif; ?>
                </p>
                <?php endif; ?>
            </div>
            <button onclick="tgClosePrefs()" style="background:none;border:none;cursor:pointer;font-size:20px;color:<?= esc_attr($c_txt) ?>;opacity:.35;line-height:1;padding:0 4px;flex-shrink:0;margin-top:-1px;transition:opacity .15s" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='.35'">×</button>
        </div>
        <div id="tg-cats" style="border-top:1px solid <?= esc_attr($c_txt) ?>15"></div>
        <div style="display:flex;gap:8px;margin-top:18px;flex-wrap:wrap;align-items:center">
            <button onclick="tgDeclineAll()" style="background:transparent;color:<?= esc_attr($c_txt) ?>;border:1.5px solid <?= esc_attr($c_txt) ?>30;padding:8px 16px;border-radius:7px;cursor:pointer;font-family:'Manrope',sans-serif;font-size:12.5px;font-weight:500">Decline All</button>
            <button onclick="tgSaveCustom()" style="background:transparent;color:<?= esc_attr($c_txt) ?>;border:1.5px solid <?= esc_attr($c_txt) ?>;padding:8px 16px;border-radius:7px;cursor:pointer;font-family:'Manrope',sans-serif;font-size:12.5px;font-weight:500;margin-left:auto">Save</button>
            <button onclick="tgAcceptAll()" style="background:<?= esc_attr($c_pri) ?>;color:#fff;border:none;padding:8px 18px;border-radius:7px;cursor:pointer;font-family:'Manrope',sans-serif;font-size:12.5px;font-weight:600">Accept All</button>
        </div>
    </div>
</div>

<script>
(function(){
    var CATS=[
        {id:'analytics', label:'Analytics',
         desc:'Helps us understand how visitors use the site. Powers tools like Google Analytics.',
         keys:['analytics_storage']},
        {id:'advertising', label:'Advertising',
         desc:'Enables personalised ads and conversion measurement across Google Ads, Meta, and similar platforms.',
         keys:['ad_storage','ad_user_data','ad_personalization']},
        {id:'functional', label:'Functional',
         desc:'Remembers your preferences and settings to personalise your experience.',
         keys:['functionality_storage','personalization_storage']}
    ];
    var ALL_KEYS=['analytics_storage','ad_storage','ad_user_data','ad_personalization',
                  'functionality_storage','personalization_storage','security_storage'];
    var IS_MODAL=<?= $is_modal ? 'true' : 'false' ?>;
    var PAGE_BLOCK=<?= $page_block ? 'true' : 'false' ?>;
    var SEND_GW=<?= $send_gateway ?>;
    var PUSH_DL=<?= $push_dl ?>;
    var RELOAD=<?= $reload_js ?>;           // reload after Save Preferences (prefs panel)
    var RELOAD_CONSENT=<?= $reload_consent_js ?>; // reload after Accept All / Decline All (banner)
    var C_PRI='<?= esc_js($c_pri) ?>';
    var C_BG='<?= esc_js($c_bg) ?>';
    var C_TXT='<?= esc_js($c_txt) ?>';

    // ── Preference state — source of truth for the toggles ──────────────────
    var _prefs={};

    // ── Cookie helpers ──────────────────────────────────────────────────────
    function tgRC(n){
        var m=document.cookie.match(new RegExp('(?:^|;\\s*)'+n+'=([^;]*)'));
        return m?decodeURIComponent(m[1]):null;
    }

    // ── Read consent (JSON or legacy string) ─────────────────────────────────
    function getState(){
        var raw=tgRC('tagify_consent');
        if(!raw) return null;
        try{var p=JSON.parse(raw);if(p&&typeof p==='object')return p;}catch(e){}
        var s={};
        ALL_KEYS.forEach(function(k){
            s[k]=(raw==='granted')?'granted':
                 (window.TagifyConfig&&window.TagifyConfig.consentPreset?
                  (window.TagifyConfig.consentPreset[k]||'denied'):'denied');
        });
        s.security_storage='granted';
        return s;
    }

    // ── Write consent ────────────────────────────────────────────────────────
    function setState(s){
        s.security_storage='granted';
        var sec=location.protocol==='https:';
        document.cookie='tagify_consent='+encodeURIComponent(JSON.stringify(s))+
            ';path=/;max-age='+(365*24*3600)+';SameSite=Lax'+(sec?';Secure':'');
        if(window.TagifyConfig) window.TagifyConfig.currentConsent=s;
        if(typeof gtag==='function') gtag('consent','update',s);
    }

    function allGranted(){var s={};ALL_KEYS.forEach(function(k){s[k]='granted';});return s;}
    function declined(){
        var b=(window.TagifyConfig&&window.TagifyConfig.consentPreset)?
            JSON.parse(JSON.stringify(window.TagifyConfig.consentPreset)):{};
        b.security_storage='granted';return b;
    }

    // ── Overlay (page blocking) ──────────────────────────────────────────────
    function lockPage(){
        if(PAGE_BLOCK){
            var ov=document.getElementById('tg-consent-overlay');
            if(ov) ov.style.display='block';
            document.documentElement.style.overflow='hidden';
        }
    }
    function unlockPage(){
        if(PAGE_BLOCK){
            var ov=document.getElementById('tg-consent-overlay');
            if(ov) ov.style.display='none';
            document.documentElement.style.overflow='';
        }
    }

    // ── Banner ───────────────────────────────────────────────────────────────
    function showBanner(){
        var b=document.getElementById('tg-consent-banner');
        if(b) b.style.display='flex';
        lockPage();
    }
    function hideBanner(){
        var b=document.getElementById('tg-consent-banner');
        if(b) b.style.display='none';
        unlockPage();
    }

    // ── Floating button ──────────────────────────────────────────────────────
    function showManageBtn(){
        var b=document.getElementById('tg-manage-btn');
        if(b) b.style.display='flex';
    }
    function hideManageBtn(){
        var b=document.getElementById('tg-manage-btn');
        if(b) b.style.display='none';
    }

    // ── Build category rows ───────────────────────────────────────────────────
    function buildCats(state){
        var el=document.getElementById('tg-cats');
        if(!el) return;
        var preset=(window.TagifyConfig&&window.TagifyConfig.consentPreset)||{};

        CATS.forEach(function(cat){
            if(state) _prefs[cat.id]=cat.keys.every(function(k){return state[k]==='granted';});
            else       _prefs[cat.id]=cat.keys.every(function(k){return(preset[k]||'denied')==='granted';});
        });

        var sep='border-bottom:1px solid '+C_TXT+'18';
        var html='<div style="display:flex;justify-content:space-between;align-items:flex-start;padding:14px 0;'+sep+'">'
            +'<div><div style="font-weight:600;font-size:13px;color:'+C_TXT+';margin-bottom:3px">Necessary '
            +'<span style="font-size:11px;background:'+C_TXT+'12;color:'+C_TXT+';opacity:.6;font-weight:400;padding:2px 8px;border-radius:10px">Always on</span></div>'
            +'<div style="font-size:12px;color:'+C_TXT+';opacity:.55;line-height:1.55;margin-top:3px">Strictly required for the website to function properly.</div>'
            +'</div><span style="font-size:18px;flex-shrink:0;padding-top:2px">🔒</span></div>';

        CATS.forEach(function(cat){
            var on=_prefs[cat.id];
            html+='<div style="display:flex;justify-content:space-between;align-items:flex-start;padding:14px 0;'+sep+'">'
                +'<div style="flex:1;padding-right:16px">'
                +'<div style="font-weight:600;font-size:13px;color:'+C_TXT+';margin-bottom:3px">'+cat.label+'</div>'
                +'<div style="font-size:12px;color:'+C_TXT+';opacity:.55;line-height:1.55;margin-top:3px">'+cat.desc+'</div>'
                +'</div>'
                +'<div id="tg-tog-'+cat.id+'" role="switch" aria-checked="'+(on?'true':'false')+'" tabindex="0" '
                +'style="flex-shrink:0;margin-top:2px;position:relative;width:42px;height:23px;border-radius:23px;'
                +'background:'+(on?C_PRI:'#c8c4bc')+';cursor:pointer;transition:background .2s;outline:none">'
                +'<span style="position:absolute;left:'+(on?'22':'3')+'px;bottom:3px;width:17px;height:17px;'
                +'background:#fff;border-radius:50%;transition:left .2s;box-shadow:0 1px 3px rgba(0,0,0,.2)"></span>'
                +'</div></div>';
        });
        el.innerHTML=html;

        CATS.forEach(function(cat){
            var tog=document.getElementById('tg-tog-'+cat.id);
            if(!tog) return;
            function doToggle(){
                _prefs[cat.id]=!_prefs[cat.id];
                var on=_prefs[cat.id];
                tog.style.background=on?C_PRI:'#c8c4bc';
                tog.setAttribute('aria-checked',on?'true':'false');
                var dot=tog.querySelector('span');
                if(dot) dot.style.left=on?'22px':'3px';
            }
            tog.addEventListener('click',doToggle);
            tog.addEventListener('keydown',function(e){if(e.key===' '||e.key==='Enter'){e.preventDefault();doToggle();}});
        });
    }

    // ── Preferences panel ─────────────────────────────────────────────────────
    function tgOpenPrefs(){
        buildCats(getState());
        var p=document.getElementById('tg-prefs-panel');
        var bd=document.getElementById('tg-prefs-bd');
        if(p) p.style.display='block';
        if(bd) bd.style.display='block';
        document.documentElement.style.overflow='hidden';
        hideManageBtn();
    }
    function tgClosePrefs(){
        var p=document.getElementById('tg-prefs-panel');
        var bd=document.getElementById('tg-prefs-bd');
        if(p) p.style.display='none';
        if(bd) bd.style.display='none';
        document.documentElement.style.overflow='';
        showManageBtn();
    }

    // ── Post-consent helper ───────────────────────────────────────────────────
    // reloadType: 'consent' = Accept/Decline All  |  'prefs' = Save Preferences
    function afterConsent(s, reloadType){
        setState(s);
        hideBanner();
        tgClosePrefs();
        showManageBtn();
        if(typeof window.tgReinitAfterConsent==='function') window.tgReinitAfterConsent(s);
        var shouldReload=(reloadType==='consent') ? RELOAD_CONSENT : RELOAD;
        if(shouldReload){ setTimeout(function(){ window.location.reload(); },150); }
    }

    // ── Accept All ────────────────────────────────────────────────────────────
    function tgAcceptAll(){
        var s=allGranted();
        afterConsent(s,'consent');
        if(SEND_GW&&typeof window.Tagify!=='undefined') Tagify.track('consent_granted',{},{});
        if(PUSH_DL){window.dataLayer=window.dataLayer||[];window.dataLayer.push({event:'consent_granted'});}
    }

    // ── Decline All ───────────────────────────────────────────────────────────
    function tgDeclineAll(){ afterConsent(declined(),'consent'); }

    // ── Save custom prefs ─────────────────────────────────────────────────────
    function tgSaveCustom(){
        var s=declined();
        CATS.forEach(function(cat){
            var v=_prefs[cat.id]?'granted':'denied';
            cat.keys.forEach(function(k){s[k]=v;});
        });
        afterConsent(s,'prefs');
    }

    // ── Expose globals ────────────────────────────────────────────────────────
    window.tgAcceptAll=tgAcceptAll;window.tgDeclineAll=tgDeclineAll;
    window.tgOpenPrefs=tgOpenPrefs;window.tgClosePrefs=tgClosePrefs;
    window.tgSaveCustom=tgSaveCustom;
    window.tgConsent=function(c){c==='granted'?tgAcceptAll():tgDeclineAll();};

    // ── Initialise ────────────────────────────────────────────────────────────
    var existing=getState();
    if(!existing){
        showBanner();
    } else {
        if(window.TagifyConfig) window.TagifyConfig.currentConsent=existing;
        showManageBtn();
    }
})();
</script>
        <?php
    }





    public function track_purchase( $order_id ) {
        if ( ! $order_id ) return;
        $order = wc_get_order( $order_id );
        if ( ! $order instanceof WC_Order ) return;

        // Deduplication guard
        if ( $order->get_meta( '_tagify_tracked' ) ) return;
        $order->update_meta_data( '_tagify_tracked', '1' );
        $order->save();

        $pixel_key = $this->get( 'pixel_key' );
        if ( ! $pixel_key ) return;

        $cdp_items = [];
        $ga4_items = [];

        foreach ( $order->get_items() as $item ) {
            $product   = $item->get_product();
            $pid       = $product ? (string) ( $product->get_sku() ?: $product->get_id() ) : (string) $item->get_product_id();
            $qty       = (int) $item->get_quantity();
            $price     = (float) $order->get_line_subtotal( $item ) / max( $qty, 1 );
            $item_name = $item->get_name();

            $cdp_items[] = [ 'item_id' => $pid, 'item_name' => $item_name, 'price' => $price, 'quantity' => $qty ];
            $ga4_items[] = [ 'item_id' => $pid, 'item_name' => $item_name, 'price' => $price, 'quantity' => $qty, 'currency' => $order->get_currency() ];
        }

        $total        = (float) $order->get_total();
        $currency     = $order->get_currency();
        $order_id_str = (string) $order_id;

        $cdp_purchase_json = wp_json_encode( [
            'transaction_id' => $order_id_str,
            'value'          => $total,
            'currency'       => $currency,
            'items'          => $cdp_items,
        ] );

        $ga4_purchase_json = wp_json_encode( [
            'transaction_id' => $order_id_str,
            'value'          => $total,
            'currency'       => $currency,
            'items'          => $ga4_items,
        ] );

        $user_data_json = wp_json_encode( [
            'em'      => $order->get_billing_email(),
            'ph'      => $order->get_billing_phone(),
            'fn'      => $order->get_billing_first_name(),
            'ln'      => $order->get_billing_last_name(),
            'ct'      => $order->get_billing_city(),
            'st'      => $order->get_billing_state(),
            'zp'      => $order->get_billing_postcode(),
            'country' => $order->get_billing_country(),
        ] );

        // Separate prolonging flags for Gateway vs DataLayer
        $gw_prolong   = $this->get( 'user_data_prolonging' )  === '1';
        $dl_prolong   = $this->get( 'dl_user_prolonging' )    === '1';
        $dl_ecom_bool = $this->get( 'dl_ecommerce' )          === '1';
        $dl_ud_bool   = $this->get( 'dl_user_data' )          === '1';
        $dl_dec_bool  = $this->get( 'dl_decorate' )           === '1';
        ?>
<!-- Tagify Gateway: Purchase Event -->
<script>
(function(){
    function tgGet(k){
        var n=k+'=',ca=document.cookie.split(';');
        for(var i=0;i<ca.length;i++){var c=ca[i].trim();if(c.indexOf(n)===0)return decodeURIComponent(c.substring(n.length));}
        try{return localStorage.getItem(k);}catch(e){return null;}
    }

    var uData  = <?= $user_data_json ?>;
    var cdpData= <?= $cdp_purchase_json ?>;
    var ga4Data= <?= $ga4_purchase_json ?>;

    // Enrich with stored click-IDs
    if(tgGet('_tg_ttclid'))  uData.ttclid  = tgGet('_tg_ttclid');
    if(tgGet('_tg_ttp'))     uData.ttp     = tgGet('_tg_ttp');
    if(tgGet('_tg_fbc'))     uData.fbc     = tgGet('_tg_fbc');
    if(tgGet('_tg_fbp'))     uData.fbp     = tgGet('_tg_fbp');
    if(tgGet('_tg_sccid'))   uData.sccid   = tgGet('_tg_sccid');
    if(tgGet('_tg_gclid'))   uData.gclid   = tgGet('_tg_gclid');
    uData.client_id = tgGet('_tg_client_id');

    // Store for Gateway future page views (independent of DL)
    if(<?= $gw_prolong ? 'true' : 'false' ?>){
        try{
            localStorage.setItem('_tg_user_data', JSON.stringify({
                em:uData.em, ph:uData.ph, fn:uData.fn, ln:uData.ln,
                ct:uData.ct, st:uData.st, zp:uData.zp, country:uData.country
            }));
        }catch(e){}
    }

    // Store separately for DataLayer future page views (independent of GW)
    if(<?= $dl_prolong ? 'true' : 'false' ?>){
        try{
            localStorage.setItem('_tg_dl_user_data', JSON.stringify({
                em:uData.em, ph:uData.ph, fn:uData.fn, ln:uData.ln,
                ct:uData.ct, st:uData.st, zp:uData.zp, country:uData.country
            }));
        }catch(e){}
    }

    // ── Gateway purchase ───────────────────────────────────────────────────
    function fireGateway(){
        if(typeof window.Tagify==='undefined') return;
        if(typeof Tagify.init==='function'){
            Tagify.init(window.TagifyConfig.pixelKey,{endpoint:window.TagifyConfig.endpoint});
        }
        cdpData.pixel_key=window.TagifyConfig ? window.TagifyConfig.pixelKey : '';
        Tagify.track('purchase', cdpData, uData);
    }
    function whenTagifyReady(fn,retries){
        retries=retries||0;
        if(typeof window.Tagify!=='undefined'){fn();}
        else if(retries<80){setTimeout(function(){whenTagifyReady(fn,retries+1);},50);}
    }

    // ── DataLayer purchase ─────────────────────────────────────────────────
    function fireDataLayer(){
        if(!<?= $dl_ecom_bool ? 'true' : 'false' ?>) return;
        var eventName=<?= $dl_dec_bool ? "'purchase_tagify'" : "'purchase'" ?>;
        var payload={event:eventName, ecommerce:ga4Data};
        if(<?= $dl_ud_bool ? 'true' : 'false' ?>) payload.user_data=uData;
        window.dataLayer=window.dataLayer||[];
        window.dataLayer.push(payload);
    }

    window.addEventListener('load',function(){
        whenTagifyReady(fireGateway);
        fireDataLayer();
    });
})();
</script>
        <?php
    }

    /* ------------------------------------------------------------------ */
    /*  WEBHOOKS                                                            */
    /* ------------------------------------------------------------------ */

    private function build_webhook_payload( WC_Order $order, string $event ): array {
        $items = [];
        foreach ( $order->get_items() as $item ) {
            $items[] = [
                'product_id'   => $item->get_product_id(),
                'product_name' => $item->get_name(),
                'quantity'     => $item->get_quantity(),
                'subtotal'     => $order->get_line_subtotal( $item ),
            ];
        }
        return [
            'event'          => $event,
            'timestamp'      => time(),
            'order_id'       => $order->get_id(),
            'order_number'   => $order->get_order_number(),
            'order_status'   => $order->get_status(),
            'order_total'    => (float) $order->get_total(),
            'currency'       => $order->get_currency(),
            'items'          => $items,
            'customer_email' => $order->get_billing_email(),
            'customer_phone' => $order->get_billing_phone(),
            'customer_name'  => $order->get_formatted_billing_full_name(),
            'billing'        => [
                'city'    => $order->get_billing_city(),
                'state'   => $order->get_billing_state(),
                'country' => $order->get_billing_country(),
                'zip'     => $order->get_billing_postcode(),
            ],
        ];
    }

    private function fire_webhook( WC_Order $order, string $event ): void {
        if ( $this->get( 'wh_enabled' ) !== '1' ) return;
        $url = $this->get( 'wh_url' );
        if ( ! $url ) return;
        wp_remote_post( $url, [
            'headers'     => [ 'Content-Type' => 'application/json' ],
            'body'        => wp_json_encode( $this->build_webhook_payload( $order, $event ) ),
            'timeout'     => 10,
            'blocking'    => false,
            'data_format' => 'body',
        ] );
    }

    public function webhook_purchase( $order_id ) {
        if ( $this->get( 'wh_purchase' ) !== '1' ) return;
        $order = wc_get_order( $order_id );
        if ( $order instanceof WC_Order ) $this->fire_webhook( $order, 'new_order' );
    }

    public function webhook_processing( $order_id ) {
        if ( $this->get( 'wh_processing' ) !== '1' ) return;
        $order = wc_get_order( $order_id );
        if ( $order instanceof WC_Order ) $this->fire_webhook( $order, 'order_processing' );
    }

    public function webhook_completed( $order_id ) {
        if ( $this->get( 'wh_completed' ) !== '1' ) return;
        $order = wc_get_order( $order_id );
        if ( $order instanceof WC_Order ) $this->fire_webhook( $order, 'order_completed' );
    }

    public function webhook_refund( $order_id ) {
        if ( $this->get( 'wh_refund' ) !== '1' ) return;
        $order = wc_get_order( $order_id );
        if ( $order instanceof WC_Order ) $this->fire_webhook( $order, 'order_refunded' );
    }
}

new Tagify_Ultimate_Pixel();